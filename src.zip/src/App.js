import RouteFile from "./components/RouteFile";

function App() {
  return (
    <>
      <RouteFile />
    </>
  );
}

export default App;
