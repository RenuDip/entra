import {configureStore} from '@reduxjs/toolkit'; 
import viewGroupSlice from '../feature/groups/viewGroupSlice';
import manageGroupSlice from '../feature/groups/manageGroupSlice';
import requestGroupSlice from '../feature/groups/requestGroupSlice';
import accessRequestSlice from '../feature/accessPackage/accessRequestSlice';
import requestAppSlice from '../feature/my-app/requestAppSlice';
import historyAppSlice from '../feature/my-app/historyAppSlice';
import accessViewSlice from '../feature/accessPackage/accessViewSlice';
import accessHistorySlice from '../feature/accessPackage/accessHistorySlice';

const store =configureStore({
    reducer : {
        accessView: accessViewSlice,
        groupManage:manageGroupSlice,
        requestGroup:requestGroupSlice,
        groupView:viewGroupSlice,
        accessrequest:accessRequestSlice,
        requestApp:requestAppSlice,
        HistoryApp:historyAppSlice,
        accessHistory:accessHistorySlice

    }
});

export default store;