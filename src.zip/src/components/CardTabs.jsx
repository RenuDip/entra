import React, { useState } from 'react';
import Card from './card'



const CardTabs = ({ cards }) => {
  const [activeTab, setActiveTab] = useState('Groups'); // Initial active tab state

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  const renderFilteredCards = () => {
    // Filter cards based on active tab
    const filteredCards = cards.filter(card => {
      if (activeTab === 'Groups') {
        return card.applicationType === 'Group';
      } else if (activeTab === 'Access Packages') {
        return card.applicationType === 'Access Package';
      } else if (activeTab === 'Apps') {
        return card.applicationType === 'App';
      }
      return true; // Return true for all cards if no specific condition matches
    });

    // Render filtered cards
    return filteredCards.map((card, index) => (
      <Card
        key={index}
        id={index} // Provide a unique key for each card
        requestName={card.requestName}
        requestedBy={card.requestedBy}
        approvalDate={card.approvalDate}
        applicationType={card.applicationType} // Pass applicationType to Card component
      />
    ));
  };

  return (
    <div>
      <div className="MyActionPanel-ChipsContainer">
        <button
          className={`Access-Panel-light-button ${activeTab === 'Access Packages' ? 'active' : ''}`}
          onClick={() => handleTabClick('Access Packages')}
        >
          Access Packages
        </button>
        <button
          className={`Groups-light-button ${activeTab === 'Groups' ? 'active' : ''}`}
          onClick={() => handleTabClick('Groups')}
        >
          Groups
        </button>
        <button
          className={`Apps-light-button ${activeTab === 'Apps' ? 'active' : ''}`}
          onClick={() => handleTabClick('Apps')}
        >
          Apps
        </button>
      </div>
      <div className="accordion" id="accordionExample">
        {renderFilteredCards()}
      </div>
    </div>
  );
};

export default CardTabs;
