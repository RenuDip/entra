import React, { useState, useEffect } from 'react';
import userData from '../app/userData.json';
import SpannerIcon from '../components/Shared/SpannerIcon';
import EyeIcon from '../components/Shared/EyeIcon';

import gmailPng from '../assets/images/gmail.png';
import drivePng from '../assets/images/drive.png';
import zohoPng from '../assets/images/zoho.png';

const imageMap = {
  'gmail.png': gmailPng,
  'drive.png': drivePng,
  'zoho.png': zohoPng,
};

const DashTabs = ({ rightContainerOpen, toggleRightContainer }) => {
  const [data, setData] = useState([]);
  const [activeTab, setActiveTab] = useState('All');

  useEffect(() => {
    setData(userData.appsData);
  }, []);

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };


  const filteredData = activeTab === 'All'
    ? userData.appsData
    : userData.appsData.filter((item) => item.type === activeTab.toLowerCase());

  console.log('isRightContainerOpen:', rightContainerOpen); // Log to check state

  return (
    <div className="container">
      <div className="row mt-5">
        <div className="col-md-10">
          <ul className={`nav nav-pills mb-3 ms-5 transition-width ${rightContainerOpen ? 'open' : 'closed'}`} id="pills-tab" role="tablist" style={{ width: rightContainerOpen ? '48%' : '43.5%' }}>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link btn-pills btn-all  ${activeTab === 'All' ? 'active' : ''}` } style={{position: 'relative', top: '-3px'}}
                id="pills-home-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-home"
                type="button"
                role="tab"
                aria-controls="pills-home"
                aria-selected={activeTab === 'All'}
                onClick={() => handleTabClick('All')}
              >
                All
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link btn-pills btn-creative ${activeTab === 'Creative' ? 'active' : ''}`}
                id="pills-profile-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-profile"
                type="button"
                role="tab"
                aria-controls="pills-profile"
                aria-selected={activeTab === 'Creative'}
                onClick={() => handleTabClick('Creative')}
              >
                Creative
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link btn-pills btn-admin ${activeTab === 'Admin' ? 'active' : ''}`}
                id="pills-contact-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-contact"
                type="button"
                role="tab"
                aria-controls="pills-contact"
                aria-selected={activeTab === 'Admin'}
                onClick={() => handleTabClick('Admin')}
              >
                Admin
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link btn-pills btn-requested ${activeTab === 'Requested' ? 'active' : ''}`}
                id="pills-request-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-request"
                type="button"
                role="tab"
                aria-controls="pills-request"
                aria-selected={activeTab === 'Requested'}
                onClick={() => handleTabClick('Requested')}
              >
                Requested
              </button>
            </li>
          </ul>
        </div>
        <div className="col-md-2 text-center">
          <div className='frame102'>
            <button className="spannericon-btn" >
              <SpannerIcon />
            </button>
            <button className="eyeicon-btn" >
              <EyeIcon />
            </button>
          </div>
        </div>
      </div>

      <div className="tab-content m-4" id="pills-tabContent" style={{width: rightContainerOpen ?'':'1296px', position: rightContainerOpen ? '' : 'relative', left: rightContainerOpen ?'': '-96px'}}>
        <div
          className={`tab-pane fade show ${activeTab === 'All' ? 'active' : ''} m-4`}
          id="pills-home"
          role="tabpanel"
          aria-labelledby="pills-home-tab"
          tabIndex="0"
        >
          <div className={`row ${rightContainerOpen ? 'row-cols-2 row-cols-md-6' : 'row-cols-8'} g-4`}>
            {filteredData.map((item, index) => (
              <div className="col" key={index}>
                <div className="card card-dashbooard m-4">
                  <span className="dots-thre"> &#x2807;</span>
                  <div className="img-containe">
                    <img
                      src={imageMap[item.image]}
                      className="card-img-top mx-auto"
                      alt={item.title}
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = 'path/to/default/image.png'; // Provide a fallback image if needed
                      }}
                    />
                  </div>
                  <div className="card-body-dash">
                    <h5 className="card-title bg-gray">{item.title}</h5>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div
          className={`tab-pane fade show ${activeTab === 'Creative' ? 'active' : ''} m-4`}
          id="pills-profile"
          role="tabpanel"
          aria-labelledby="pills-profile-tab"
          tabIndex="0"
        >
          <div className={`row ${rightContainerOpen ? 'row-cols-2 row-cols-md-6' : 'row-cols-8'} g-4`}>
            {filteredData.map((item, index) => (
              <div className="col" key={index}>
                <div className="card card-dashbooard m-4">
                  <span className="dots-thre"> &#x2807;</span>
                  <div className="img-containe">
                    <img
                      src={imageMap[item.image]}
                      className="card-img-top mx-auto"
                      alt={item.title}
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = 'path/to/default/image.png'; // Provide a fallback image if needed
                      }}
                    />
                  </div>
                  <div className="card-body-dash">
                    <h5 className="card-title bg-gray">{item.title}</h5>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div
          className={`tab-pane fade show ${activeTab === 'Admin' ? 'active' : ''} m-4`}
          id="pills-contact"
          role="tabpanel"
          aria-labelledby="pills-contact-tab"
          tabIndex="0"
        >
          <div className={`row ${rightContainerOpen ? 'row-cols-2 row-cols-md-6' : 'row-cols-8'} g-4`}>
            {filteredData.map((item, index) => (
              <div className="col" key={index}>
                <div className="card card-dashbooard m-4">
                  <span className="dots-thre"> &#x2807;</span>
                  <div className="img-containe">
                    <img
                      src={imageMap[item.image]}
                      className="card-img-top mx-auto"
                      alt={item.title}
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = 'path/to/default/image.png'; // Provide a fallback image if needed
                      }}
                    />
                  </div>
                  <div className="card-body-dash">
                    <h5 className="card-title bg-gray">{item.title}</h5>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div
          className={`tab-pane fade show ${activeTab === 'Requested' ? 'active' : ''} m-4`}
          id="pills-request"
          role="tabpanel"
          aria-labelledby="pills-request-tab"
          tabIndex="0"
        >
          <div className={`row ${rightContainerOpen ? 'row-cols-2 row-cols-md-6' : 'row-cols-8'} g-4`}>
            {filteredData.map((item, index) => (
              <div className="col" key={index}>
                <div className="card card-dashbooard m-4">
                  <span className="dots-thre"> &#x2807;</span>
                  <div className="img-containe">
                    <img
                      src={imageMap[item.image]}
                      className="card-img-top mx-auto"
                      alt={item.title}
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = 'path/to/default/image.png'; // Provide a fallback image if needed
                      }}
                    />
                  </div>
                  <div className="card-body-dash">
                    <h5 className="card-title bg-gray">{item.title}</h5>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashTabs;
