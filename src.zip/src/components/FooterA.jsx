import React from 'react'

const FooterA = () => {
  return (
    <>
    <div className='footer p-4'>
    <div className="row">
      <div className="col-md-6 text-end"> Inspirit Vision 2014</div>
      <div className="col-md-6 text-end">Contact Support</div>
    </div>
    </div>
    </>
  )
}

export default FooterA