import React, { useState, useEffect, useRef } from 'react';
import './Header.scss'; // Import your Header component styling
import logo from '../assets/images/comp-logo.png';
import { NavLink, useLocation } from 'react-router-dom';
import { ReactComponent as ProfileIcon } from '../assets/icons/User Thumb.svg'; // Adjusted to UserThumb

import { useIsAuthenticated } from "@azure/msal-react";
import { loginRequest } from "../authConfig";
import { useMsal } from "@azure/msal-react";
import UserProfile from './UserProfile';

const Header = () => {
  const isAuthenticated = useIsAuthenticated();
  const { instance } = useMsal();
  console.log("Header: Check useIsAuthenticated: "+isAuthenticated);
  if (!isAuthenticated) {
    console.log("Header: useIsAuthenticated = false");
    instance.loginRedirect(loginRequest).catch((e) => {
      console.log(e);
    });
  }
  const location = useLocation();
  const [activeTabPosition, setActiveTabPosition] = useState({ left: 0, width: 0 });

  // Define the paths that should activate the "Self Service" link
  const selfServicePaths = [
    '/self-service/my-access-packages',
    '/self-service/my-groups',
    '/self-service/my-apps'
  ];

  // Function to determine if the "Self Service" link should be active
  const isActiveSelfService = () => {
    return selfServicePaths.some(path => location.pathname.startsWith(path));
  };

  // Function to determine if the "Approval" link should be active
  const isActiveApproval = () => {
    return location.pathname.startsWith('/approval');
  };

  const navBarRef = useRef(null);

  // Calculate position of TabSlider based on active NavLink
  const calculateTabSliderPosition = () => {
    const activeNavLink = navBarRef.current.querySelector('.nav-link.active');
    if (activeNavLink) {
      const navBarRect = navBarRef.current.getBoundingClientRect();
      const activeNavLinkRect = activeNavLink.getBoundingClientRect();
      return {
        left: activeNavLinkRect.left - navBarRect.left,
        width: activeNavLinkRect.width
      };
    }
    return { left: 0, width: 0 };
  };

  useEffect(() => {
    const updateTabSliderPosition = () => {
      setActiveTabPosition(calculateTabSliderPosition());
    };
    const timer = setTimeout(updateTabSliderPosition, 100);
    window.addEventListener('resize', updateTabSliderPosition);
    return () => {
      clearTimeout(timer);
      window.removeEventListener('resize', updateTabSliderPosition);
    };
  }, [location]);

  return (
    <div className="row">
      <nav className="navbar navbar-expand-lg fixed-top">
        <div className="container-fluid px-4">
          <NavLink className="navbar-logo" to="/">
            <img src={logo} alt="Logo" height="50" className="d-inline-block align-top" />
          </NavLink>
          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarSupportedContent">
            <ul ref={navBarRef} className="navbar-PageNames" style={{ position: 'relative' }}>
              <li className="nav-item">
                <NavLink className={`nav-link ${location.pathname === '/' ? 'active' : ''}`} to="/">
                  Dashboard
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  className={`nav-link ${isActiveSelfService() ? 'active' : ''}`}
                  to="/self-service/my-apps/my-view"
                >
                  Self-Service
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink
                  className={`nav-link ${isActiveApproval() ? 'active' : ''}`}
                  to="/approval/access-review"
                >
                  Approval
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink className={`nav-link ${location.pathname === '/insights' ? 'active' : ''}`} to="/insights">
                  Insights
                </NavLink>
              </li>
              {/* <li className="nav-item">
                <NavLink className={`nav-link ${location.pathname === '/manage' ? 'active' : ''}`} to="/manage">
                  Manage
                </NavLink>
              </li> */}
              <li className="nav-item user-icon">
              <a
                  className="nav-link dropdown-toggle"
                  href="#"
                  id="profileDropdown"
                  role="button"
                  data-bs-toggle="dropdown"
                  aria-expanded="false"
                >
                <ProfileIcon />
                </a>
                <ul className="dropdown-menu box arrow-top" aria-labelledby="profileDropdown">
                 <UserProfile/>
                </ul>
              </li>
              <div
                className="TabSlider"
                style={{
                  left: `${activeTabPosition.left}px`,
                  width: `${activeTabPosition.width}px`
                }}
              ></div>
            </ul>
          </div>
        </div>
      </nav>
    </div>
  );
};

export default Header;
