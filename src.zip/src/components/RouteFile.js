import React from 'react'
import Header from '../components/Header';
import Dashboard from '../pages/Dashboard';
import Insights from '../pages/Insights';
import Manage from '../pages/Manage';
import {BrowserRouter, Routes, Route} from "react-router-dom";
import ViewAccessPackages from '../pages/SelfService/MyAccessPackages/ViewAccessPackages';

import RequestAccessPackages from '../pages/SelfService/MyAccessPackages/RequestAccessPackages';
import AccessPackageHistory from '../pages/SelfService/MyAccessPackages/AccessPackageHistory';
//import GroupHistory from '../pages/SelfService/MyGroup/GroupHistory';
import ManageGroup from '../pages/SelfService/MyGroup/ManageGroup';
import AccessPackageAprReq from '../pages/Approvals/ApproveRequest/AccessPackageAprReq';
import GroupAprReq from '../pages/Approvals/ApproveRequest/GroupAprReq';
import AppsAprRequest from '../pages/Approvals/ApproveRequest/AppsAprRequest';
import AccessReview from '../pages/Approvals/Review/AccessReview';
import Responsibilities from '../pages/Approvals/Overview/Responsibilities';
import RequestApp from '../pages/SelfService/MyApp/RequestApp';
import RequestHistoryApp from '../pages/SelfService/MyApp/RequestHistoryApp';
import RequestGroup from '../pages/SelfService/MyGroup/RequestGroup';
import MyApp from '../pages/SelfService/MyApp/MyApp';
import ViewGroup from '../pages/SelfService/MyGroup/ViewGroup';
import ScrollToTop from './ScrollToTop';


const RouteFile = () => {
  return (
    <BrowserRouter>
   <ScrollToTop/>
<Header />
<Routes>
 <Route path ="/" element={<Dashboard/>}/>
 <Route path ="/insights" element={<Insights/>}/>
 <Route path='/self-service/my-access-packages/view' element={<ViewAccessPackages/>}/>
 <Route path='/self-service/my-access-packages/request-app' element={<RequestAccessPackages/>}/>
 <Route path='/self-service/my-access-packages/request-history' element={<AccessPackageHistory/>}/>
 
 <Route path='/self-service/my-apps/my-view' element ={<MyApp/>}/>
 <Route path='/self-service/my-apps/request-new' element ={<RequestApp/>}/>
 <Route path='/self-service/my-apps/request-history' element ={<RequestHistoryApp/>}/>

 
 <Route path='/self-service/my-groups/request-new' element={<RequestGroup/>}/>
 <Route path='/self-service/my-groups/manage-group' element={<ManageGroup/>}/>
 {/* <Route path='/self-service/my-groups/request-history' element={<GroupHistory/>}/> */}
 <Route path='/self-service/my-groups/view-all' element={<ViewGroup/>}/>
 <Route path="/approval" element={<AccessPackageAprReq/>} />   
 <Route path='/approval/approve-request/access-package' element={<AccessPackageAprReq/>}/>
 <Route path='/approval/approve-request/groups' element={<GroupAprReq/>}/>
 <Route path='/approval/approve-request/apps' element={<AppsAprRequest/>}/>
 <Route path='/approval/access-review' element={<AccessReview/>}/>
 <Route path='/approval/responsibilities' element={<Responsibilities/>}/>

 <Route path="/manage" element={<Manage />} /> 
 <Route path="*" element={<h1>Error 404 page not found</h1>} /> 
</Routes>
</BrowserRouter>
  )
}

export default RouteFile