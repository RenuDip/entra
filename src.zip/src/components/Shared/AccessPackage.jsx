import React from "react";
import SearchBar from "./SearchBar";
import ArrowIcon from "./arrow";

const AccessPackages = ({ handleSearchGroupsAndApps, reviewDefinitions }) => {
  return (
    <div className="access-package-container">
      <div className="header">
        <h2>Access Packages</h2>
        <div className="search-container">
          <SearchBar
            placeholder="Search ..."
            buttonLabel="Search"
            onSearch={handleSearchGroupsAndApps}
            width="184px"
            className="groups-and-apps-search-bar"
            inputClassName="custom-input"
            buttonClassName="custom-button"
            placeholderWidth="100px"
            searchPadding="0"
            iconLeft="5px"
            iconTop="0px"
          />
        </div>
      </div>
      <div className="rectangle103"></div>
      <div className="tiles-container">
        {(!reviewDefinitions || !Array.isArray(reviewDefinitions) || reviewDefinitions.length === 0) ? (
          <div>No data available</div>
        ) : (
          reviewDefinitions.map((review) => {
            const { displayName, range, status } = review;
            const endDate = new Date(range.endDate).toLocaleDateString();
            return (
              <div className="tile" key={review.id}>
                <div className="tile-content">
                  <h4>{displayName}</h4>
                  <p>
                    {status === "Completed"
                      ? `Complete by ${endDate}`
                      : `Complete by ${endDate}`}
                  </p>
                  <ArrowIcon className="arrow-icon" style={{ fill: 'blue' }} />
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};

export default AccessPackages;
