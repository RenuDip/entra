import React from "react";
import SearchBar from "./SearchBar";

const DirectReportees = ({ handleSearchApps }) => {
  return (
    <div className="approval-reportees-container">
      <div className="header">
        <h2>Assets for me to Approve</h2>
        <div className="search-container">
          <SearchBar
            placeholder="Search Assets..."
            buttonLabel="0"
            onSearch={handleSearchApps}
            width="165px"
            className="approval-search-bar"
            inputClassName="custom-input"
            buttonClassName="approval-custom-button"
            placeholderWidth="100px"
            searchPadding= "0"
            iconLeft="-10px"
            iconTop="5px"
          />
        </div>
      </div>
      {/* Add additional content for the Direct Reportees section here */}
    </div>
  );
};

export default DirectReportees;
