import React from 'react';
import userData from '../../app/userData.json';
import AppIcon from '../../components/Shared/smallApps';
import GroupIcon from '../../components/Shared/smallGroups';
import AccessPackageIcon from '../../components/Shared/smallAccessPackage';

const ApprovalAppsSection = ({ title, data, IconComponent }) => (
  <div className="approval-section">
    <div className="section-header">
      <IconComponent />
      <h3 className="approval-section-title">{title}</h3>
      <div className="app-approver-type-container">Approver Type</div>
    </div>
    <div className="approval-tiles-container">
      {data.map(item => (
        <div key={item.id} className="approval-tile">
          <div className="item-name">{item.name}</div>
          <div className="item-type">{item.type}</div>
        </div>
      ))}
    </div>
  </div>
);

const ApprovalGroupsSection = ({ title, data, IconComponent }) => (
 <div className="approval-section">
   <div className="section-header">
     <IconComponent />
     <h3 className="approval-section-title">{title}</h3>
     <div className="group-approver-type-container">Approver Type</div>
   </div>
   <div className="approval-tiles-container">
     {data.map(item => (
       <div key={item.id} className="approval-tile">
         <div className="item-name">{item.name}</div>
         <div className="item-type">{item.type}</div>
       </div>
     ))}
   </div>
 </div>
);

const ApprovalAccessPackagesSection = ({ title, data, IconComponent }) => (
 <div className="approval-section">
   <div className="section-header">
     <IconComponent />
     <h3 className="approval-section-title">{title}</h3>
     <div className="accesspackage-approver-type-container">Approver Type</div>
   </div>
   <div className="approval-tiles-container">
     {data.map(item => (
       <div key={item.id} className="approval-tile">
         <div className="item-name">{item.name}</div>
         <div className="item-type">{item.type}</div>
       </div>
     ))}
   </div>
 </div>
);

const ApprovalTile = () => {
  const { approval } = userData;
  const { apps, groups, accessPackages } = approval;

  return (
    <div className="approval-tile-container">
      <div className="approvalReportee-correction-padding">
        <ApprovalAppsSection title="Apps" data={apps} IconComponent={AppIcon} />
        <ApprovalGroupsSection title="Groups" data={groups} IconComponent={GroupIcon} />
        <ApprovalAccessPackagesSection title="Access Packages" data={accessPackages} IconComponent={AccessPackageIcon} />
      </div>
    </div>
  );
};

export default ApprovalTile;
