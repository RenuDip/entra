    import React, { useState, useEffect } from 'react';
    import Select, { components } from 'react-select';

    const CustomSelect = ({
    options,
    selectedOptions,
    handleSelectChange,
    ...props
    }) => {
    const [isAllSelected, setIsAllSelected] = useState(false);

    useEffect(() => {
        setIsAllSelected(selectedOptions.length === options.length);
    }, [selectedOptions, options]);

    const handleToggleAll = () => {
        if (isAllSelected) {
        handleSelectChange([]);
        } else {
        handleSelectChange(options);
        }
        setIsAllSelected(!isAllSelected);
    };

    const extendedOptions = [
        { label: isAllSelected ? 'Unselect All' : 'Select All', value: 'toggleAll' },
        ...options
    ];

    return (
        <div className="custom-select-container">
        <Select
            isMulti
            name="customSelect"
            options={extendedOptions}
            className="basic-multi-select"
            classNamePrefix="select"
            onChange={(selected) => {
            if (selected && selected[selected.length - 1]?.value === 'toggleAll') {
                handleToggleAll();
            } else {
                handleSelectChange(selected);
            }
            }}
            value={selectedOptions}
            components={{ MultiValueContainer, Option }}
            closeMenuOnSelect={false}
            {...props}
        />
        </div>
    );
    };

    const MultiValueContainer = ({ children, ...props }) => {
    return (
        <components.MultiValueContainer {...props}>
        {children.length > 2 ? `${children.length} selected` : children}
        </components.MultiValueContainer>
    );
    };

    const Option = (props) => {
    const handleChange = () => {
        props.selectOption(props.data);
    };

    return (
        <components.Option {...props}>
        <label style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}>
            <input
            type="checkbox"
            checked={props.isSelected}
            onChange={handleChange}
            style={{ marginRight: '10px' }}
            />
            {props.isSelected && (
            <span style={{
                width: '16px',
                height: '16px',
                border: '1px solid #ccc',
                backgroundColor: '#007bff',
                color: 'white',
                textAlign: 'center',
                lineHeight: '16px',
                borderRadius: '3px',
                marginRight: '10px',
                display: 'inline-block'
            }}>
                &#10003;
            </span>
            )}
            {props.label}
        </label>
        </components.Option>
    );
    };

    export default CustomSelect;
