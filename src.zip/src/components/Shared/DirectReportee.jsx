import React from "react";
import SearchBar from "./SearchBar"; // Adjust the import path to your SearchBar component

const DirectReportees = ({ handleSearchApps }) => {
  return (
    <div className="direct-reportees-container">
      <div className="header">
        <h2>Direct Reportees</h2>
        <div className="search-container">
          <SearchBar
            placeholder="Search Reportees..."
            buttonLabel="0"
            onSearch={handleSearchApps}
            width="228px"
            className="custom-search-bar"
            inputClassName="custom-input"
            buttonClassName="custom-button"
          />
        </div>
      </div>
      {/* Add additional content for the Direct Reportees section here */}
    </div>
  );
};

export default DirectReportees;
