import React from 'react';

const DividerLine = () => {
  return <div className="divider-line"></div>;
};

export default DividerLine;
