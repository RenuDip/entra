import React from 'react';
import EyeIcon from '../../assets/icons/EyeIcon.svg'; // Import the SVG as a regular image
const ExampleComponent = () => {
  return (
    <div style={{  display: 'flex', alignItems: 'flex-start', marginTop: '0px'}}>
      <img
        src={EyeIcon}
        alt="Eye Icon"
        style={{ width: '32px', height: '32px', marginRight: '0px', marginLeft: '0px' }}
      />
    </div>
  );
};

export default ExampleComponent;
