import React from 'react';
import PropTypes from 'prop-types';

const UserList = ({ items }) => {
  return (
    <ul className="list-group list-group-flush myAccessPackage-list">
      {items.map((item, index) => (
        <React.Fragment key={index}>
          <li className="list-group-item p-3 d-flex justify-content-between align-items-center">
            {item}
          </li>
          <div className="line8"></div>
        </React.Fragment>
      ))}
    </ul>
  );
};

UserList.propTypes = {
  items: PropTypes.arrayOf(PropTypes.string).isRequired,
};

export default UserList;
