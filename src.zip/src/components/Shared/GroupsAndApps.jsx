import React, { useState, useEffect } from "react";
import SearchBar from "./SearchBar";
import ArrowIcon from "./arrow";

const GroupsAndAppsBox = ({ handleSearchGroupsAndApps, fetchReviewDefinitions, reviewDefinitions }) => {
  const [localReviewDefinitions, setLocalReviewDefinitions] = useState([]);
  const [cachedReviewDefinitions, setCachedReviewDefinitions] = useState(null);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    console.log('Review Definitions prop in GroupsAndAppsBox:', reviewDefinitions);
  }, [reviewDefinitions]);

  useEffect(() => {
    const cachedData = localStorage.getItem("reviewDefinitions");
    console.log("cachedData",cachedData)
    if (cachedData) {
      setCachedReviewDefinitions(JSON.parse(cachedData));
      setLocalReviewDefinitions(JSON.parse(cachedData));
    } else if (isActive) {
      fetchData();
    }
  }, [isActive]);

  useEffect(() => {
    if (reviewDefinitions && reviewDefinitions.value && reviewDefinitions.value.length > 0) {
      console.log('Review Definitions from props:', reviewDefinitions.value);
      setLocalReviewDefinitions(reviewDefinitions.value);
      localStorage.setItem("reviewDefinitions", JSON.stringify(reviewDefinitions.value));
    }
  }, [reviewDefinitions]);

  const fetchData = async () => {
    try {
      const data = await fetchReviewDefinitions();
      if (data && data.length > 0) {
        console.log("localReviewDefinitions :- ",localReviewDefinitions);
        setLocalReviewDefinitions(data);
        setCachedReviewDefinitions(data);
        localStorage.setItem("reviewDefinitions", JSON.stringify(data));
        console.log("localStorage",localStorage);
        console.log(data, "Data fetched and set in state");
      } else {
        console.log("Received empty data, using cached data");
      }
    } catch (error) {
      console.error("Error fetching review definitions:", error);
    }
  };

  const handlePageClick = () => {
    setIsActive(true);
    if (cachedReviewDefinitions) {
      setLocalReviewDefinitions(cachedReviewDefinitions);
    } else {
      fetchData();
    }
  };

  return (
    <div className="groups-and-apps-container" onClick={handlePageClick}>
      <div className="header">
        <h2>Groups and Apps</h2>
        <div className="search-container">
          <SearchBar
            placeholder="Search ..."
            buttonLabel="Search"
            onSearch={handleSearchGroupsAndApps}
            width="184px"
            className="groups-and-apps-search-bar"
            inputClassName="custom-input"
            buttonClassName="custom-button"
            placeholderWidth="100px"
            searchPadding="0"
            iconLeft="5px"
            iconTop="0px"
          />
        </div>
      </div>
      <div className="rectangle103"></div>
      <div className="tiles-container">
        {(localReviewDefinitions && localReviewDefinitions.length > 0) ? (
          localReviewDefinitions.map((review) => {
            const { displayName, settings } = review;
            const endDate = new Date(settings.recurrence.range.endDate).toLocaleDateString();
            return (
              <div className="tile" key={review.id}>
                <div className="tile-content">
                  <h4>{displayName}</h4>
                  <p>Complete by {endDate}</p>
                  <ArrowIcon className="arrow-icon" style={{ fill: 'blue' }} />
                </div>
              </div>
            );
          })
        ) : (
          <div>No data available</div>
        )}
      </div>
    </div>
  );
};

export default GroupsAndAppsBox;
