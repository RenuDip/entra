import React, { useState, useRef, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

const MultiSelect = ({ options, selectedOptions, handleSelectChange }) => {
  const [showDropdown, setShowDropdown] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef(null);

  const toggleOption = (option) => {
    handleSelectChange((prevSelected) => {
      if (prevSelected.includes(option)) {
        return prevSelected.filter((item) => item !== option);
      } else {
        return [...prevSelected, option];
      }
    });
  };

  const isSelected = (option) => selectedOptions.includes(option);

  const handleSelectAll = () => {
    if (selectedOptions.length === options.length) {
      // Unselect all if all options are currently selected
      handleSelectChange([]);
    } else {
      // Select all if not all options are currently selected
      handleSelectChange(options.map((option) => option.value));
    }
  };

  const handleDropdownToggle = () => {
    setShowDropdown(!showDropdown);
  };

  const handleSearchChange = (event) => {
    setSearchQuery(event.target.value);
  };

  const handleClearSearch = () => {
    setSearchQuery('');
  };

  // Filter options based on search query
  const filteredOptions = options.filter((option) =>
    option.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Generate display text based on selected options
  const getDisplayText = () => {
    if (selectedOptions.length === 0) {
      return 'Select options';
    }
    const selectedLabels = selectedOptions
      .map((value) => options.find((option) => option.value === value)?.label)
      .filter((label) => label); // Filter out undefined values

    if (selectedLabels.length <= 3) {
      // Show selected values if 3 or fewer
      return selectedLabels.join(', ');
    }

    // Show first 3 selected values with "..." if more than 3
    return `${selectedLabels.slice(0, 3).join(', ')}...`;
  };

  // Close the dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div className="dropdown multiselect" ref={dropdownRef}>
      <button
        className="btn btn-default dropdown-toggle"
        type="button"
        onClick={handleDropdownToggle}
      >
        {getDisplayText()}
        <span> &#x25BC;</span>
      </button>
      {showDropdown && (
        <div className="dropdown-menu" style={{ display: 'block' }}>
          <div className="dropdown-item d-flex align-items-center">
            <div className="search-wrapper">
              <input
                type="text"
                className="form-control"
                placeholder="Search..."
                value={searchQuery}
                onChange={handleSearchChange}
              />
              {searchQuery && (
                <button
                  type="button"
                  className="clear-btn"
                  onClick={handleClearSearch}
                >
                  &#x2715;
                </button>
              )}
            </div>
          </div>
          <div className="dropdown-item d-flex align-items-center">
            <label className="mb-0 multiselect-label">
              {selectedOptions.length === options.length ? 'Unselect All' : 'Select All'}
              <input
                type="checkbox"
                checked={selectedOptions.length === options.length}
                onChange={handleSelectAll}
                className="multiselect-checkAll"
              />
            </label>
          </div>
          {filteredOptions.length > 0 ? (
            filteredOptions.map((option) => (
              <div key={option.value} className="dropdown-item d-flex align-items-center">
                <label className="mb-0 multiselect-label">
                  <span className='option-names'>{option.label}</span>
                  <input
                    type="checkbox"
                    checked={isSelected(option.value)}
                    onChange={() => toggleOption(option.value)}
                    className="multiselect-check"
                  />
                </label>
              </div>
            ))
          ) : (
            <div className="dropdown-item">No records found</div>
          )}
        </div>
      )}
    </div>
  );
};

export default MultiSelect;
