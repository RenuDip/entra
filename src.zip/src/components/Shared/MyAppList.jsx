import React, { useState, useEffect } from 'react';
import SpannerIcon from '../../components/Shared/SpannerIcon';
import EyeIcon from '../../components/Shared/EyeIcon';
import { ReactComponent as FigmaIcon } from "../../assets/icons/figma.svg";
import { useMsal } from "@azure/msal-react";
import axios from "axios";
import configData from "../../config.json";




const MyAppList = ({ search }) => {
  const [data, setData] = useState([]);
const { instance, accounts } = useMsal();
  const [activeTab, setActiveTab] = useState('All');
  const fetchApi = async () => {
    try {
    
      const tokenResponse = await instance.acquireTokenSilent({
        scopes: ["User.Read"],
        account: accounts[0],
      });
  
      const response = await axios.get(`${configData.ENVISION_BASE_URL}/json/allTenantApplications`, {
        headers: {
          'Authorization': 'Bearer ' + tokenResponse.accessToken
        }
      });
  
      setData(response.data.appRoleAssignments);
      console.log(response.data, "Data fetched successfully");
    } catch (error) {
      console.error('Error fetching data:', error.response ? error.response.data : error.message);
    }
  };
  

  useEffect(() => {
    fetchApi();
  },[]);
  // useEffect(() => {
  //   setData(userData.appsData);
  // }, []);

  const handleTabClick = (tab) => {
    setActiveTab(tab);
  };

  const filteredData = data
  .filter(app => {
    const appType = app.type || ''; // Default to an empty string if undefined
    return activeTab === 'All' || appType.toLowerCase() === activeTab.toLowerCase();
  })
  .filter(app => (app.title || '').toLowerCase().includes(search.toLowerCase()));


  return (
    <div className="container">
      <div className="row mt-5 my-app-tabs">
        <div className="col-md-10">
          <ul className="nav nav-pills my-app-pills mb-3  ms-4rem transition-width closed " id="pills-tab" role="tablist" style={{ width: '47.2%', height :'40px' }}>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link btn-pills btn-all ${activeTab === 'All' ? 'active' : ''}`}
                id="pills-home-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-home"
                type="button"
                role="tab"
                aria-controls="pills-home"
                aria-selected={activeTab === 'All'}
                onClick={() => handleTabClick('All')}
              >
                All
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link btn-pills btn-creative ${activeTab === 'Creative' ? 'active' : ''}`}
                id="pills-profile-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-profile"
                type="button"
                role="tab"
                aria-controls="pills-profile"
                aria-selected={activeTab === 'Creative'}
                onClick={() => handleTabClick('Creative')}
              >
                Creative
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link btn-pills btn-admin ${activeTab === 'Admin' ? 'active' : ''}`}
                id="pills-contact-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-contact"
                type="button"
                role="tab"
                aria-controls="pills-contact"
                aria-selected={activeTab === 'Admin'}
                onClick={() => handleTabClick('Admin')}
              >
                Admin
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className={`nav-link btn-pills btn-requested ${activeTab === 'Requested' ? 'active' : ''}`}
                id="pills-request-tab"
                data-bs-toggle="pill"
                data-bs-target="#pills-request"
                type="button"
                role="tab"
                aria-controls="pills-request"
                aria-selected={activeTab === 'Requested'}
                onClick={() => handleTabClick('Requested')}
              >
                Requested
              </button>
            </li>
          </ul>
        </div>
        <div className="col-md-2 text-center">
          <div className='frame102'>
            <button className="spannericon-btn">
              <SpannerIcon />
            </button>
            <button className="eyeicon-btn">
              <EyeIcon />
            </button>
          </div>
        </div>
      </div>

      <div className="tab-content my-app-tab-content m-3" id="pills-tabContent">
  {['All', 'Creative', 'Admin', 'Requested'].map((tab) => (
    <div
      key={tab}
      className={`tab-pane fade show ${activeTab === tab ? 'active' : ''} `}
      id={`pills-${tab.toLowerCase()}`}
      role="tabpanel"
      aria-labelledby={`pills-${tab.toLowerCase()}-tab`}
      tabIndex="0"
    >
      <div className="row row-cols-3 row-cols-lg-4 row-cols-xl-6 g-4">
        {filteredData.map((item, index) => (
          <div className="col" key={index}>
            <div className="card card-dashbooard m-4">
              <span className="dots-thre"> &#x2807;</span>
              <div className="img-containe">
                {/* <img
                  src={<FigmaIcon/>}
                  className="card-img-top mx-auto"
                  alt={item.title}
                  onError={(e) => {
                    e.target.onerror = null;
                    e.target.src = 'path/to/default/image.png'; // Provide a fallback image if needed
                  }}
                /> */}
                {/* <FigmaIcon/> */}
                <span className='appLetter'>{item.resourceDisplayName.charAt(0).toUpperCase()}</span>
              </div>
              <div className="card-body-dash">
                <h5 className="card-title bg-gray app-list" style={{height :"40px"}}>{item.resourceDisplayName}</h5>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  ))}
</div>

    </div>
  );
};

export default MyAppList;
