import React from 'react';
import { ReactComponent as AppSvg } from '../../assets/icons/noRequests.svg';

const NoRequestsSvg = () => (
  <div className="icon-box" style={{ width: "340px", height: '240px', position: 'relative', left: '330px'}}>
    <AppSvg className="icon-svg" />
  </div>
);

export default NoRequestsSvg;
