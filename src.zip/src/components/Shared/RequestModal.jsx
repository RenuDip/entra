import React from "react";
import MultiSelect from "./MultiSelect";

const RequestModal = ({
  index,
  row,
  requiredForPeriod,
  handleToggle,
  selectedOptions,
  handleSelectChange,
  formState,
  handleJustificationChange,
  handleSubmit,
  options,
  errorMessage 
}) => {
  // Handle form submission
  const handleFormSubmit = (event) => {
    event.preventDefault(); // Prevent default form submission
    handleSubmit(index); // Call your submit handler
  };

  return (
    <div
      className="modal fade"
      id={`modal${index}`}
      data-bs-backdrop="static"
      data-bs-keyboard="false"
      tabIndex="-1"
      aria-labelledby={`modalLabel${index}`}
      aria-hidden="true"
    >
      <div className="modal-dialog modal-dialog-centered">
        <div className="modal-content P-2">
          <div className="modal-header">
            <h6 className="modal-title" id={`modalLabel${index}`}>
              {row.requestFor}||{row.appName}||{row.packageName}
            </h6>
            <button
              type="button"
              className="btn-close"
              data-bs-dismiss="modal"
              aria-label="Close"
            ></button>
          </div>
          <div className="modal-body ms-5 me-5">
            <form onSubmit={handleFormSubmit}> {/* Handle form submit */}
              <div className="mb-4 d-flex justify-content-between align-items-center">
                <label className="form-label-modal mb-0 me-2">
                  Required for a specific period?
                </label>
                <div className="form-check form-switch">
                  <input
                    className="form-check-input"
                    type="checkbox"
                    id={`specificPeriodSwitch${index}`}
                    checked={requiredForPeriod}
                    onChange={handleToggle}
                  />
                  <label
                    className="form-check-label"
                    htmlFor={`specificPeriodSwitch${index}`}
                  >
                    {requiredForPeriod ? "Yes" : "No"}
                  </label>
                </div>
              </div>
              <div className="mb-4 d-flex justify-content-between align-items-center">
                <label
                  className="form-label-modal mb-0 me-2"
                  htmlFor={`requestOnBehalf${index}`}
                >
                  Request on behalf of
                </label>
                <MultiSelect
                  options={options}
                  selectedOptions={selectedOptions}
                  handleSelectChange={handleSelectChange}
                />
              </div>
              {errorMessage && (
                <div className="alert alert-danger" role="alert">
                  {errorMessage}
                </div>
              )}
              <div className="mb-4 text-start">
                <label
                  className="form-label-modal mb-2"
                  htmlFor={`businessJustification${index}`}
                >
                  Business Justification
                  <span className="text-danger">*</span>
                </label>
                <textarea
                  className="form-control"
                  id={`businessJustification${index}`}
                  rows="3"
                  value={formState[index]?.businessJustification || ""}
                  onChange={(event) => handleJustificationChange(index, event)}
                  placeholder=""
                  required
                ></textarea>
              </div>
              <div className="modal-footer me-5">
                <button
                  type="button"
                  className="entra-button"
                  data-bs-dismiss="modal"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="btn btn-primary"
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RequestModal;
