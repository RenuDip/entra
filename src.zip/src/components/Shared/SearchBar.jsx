import React from 'react';
import PropTypes from 'prop-types';
import SearchIcon from "../../components/Shared/SearchIcon";

const SearchBar = ({
  placeholder = "What're you searching for?",
  onChange = () => {},
  width = '300px',
  height = '34px',
  className = '',
  style = {},
  inputClassName = '',
  buttonClassName = '',
  placeholderWidth ='',
  searchPadding='',
  iconLeft,
  iconTop
}) => {
  const placeholderStyle = {
    color: 'rgba(162, 169, 176, 1)',
    fontFamily: 'var(--font-family-body, Inter)',
    fontSize: 'var(--font-size-14, 14px)',
    fontStyle: 'normal',
    fontWeight: 400,
    lineHeight: '120%',
    width: placeholderWidth,
    top: '10px',
    padding: searchPadding,
  };

  const iconStyle = {
    position: 'relative',
    ...(iconLeft !== undefined && { left: iconLeft }),
    ...(iconTop !== undefined && { top: iconTop }),
  };

  return (
    <div
      className={`input-group border rounded-pill ${className}`}
      style={{ width: width, height: height, ...style }}
    >
      <input
        type="search"
        placeholder={placeholder}
        aria-describedby="button-addon3"
        className={`form-control bg-none border-0 ${inputClassName}`}
        onChange={(e) => onChange(e.target.value)} // Call onChange with the input value
        style={placeholderStyle}
      />
      <div className="input-group-append border-0" style={iconStyle}>
        <button
          id="button-addon3"
          type="button"
          className={`btn btn-link text-secondary ${buttonClassName}`}
        >
          <SearchIcon/>
        </button>
      </div>
    </div>
  );
};

SearchBar.propTypes = {
  placeholder: PropTypes.string,
  onChange: PropTypes.func,
  width: PropTypes.string,
  height: PropTypes.string,
  className: PropTypes.string,
  style: PropTypes.object,
  inputClassName: PropTypes.string,
  buttonClassName: PropTypes.string,
  placeholderWidth: PropTypes.string,
  searchPadding: PropTypes.string,
  iconLeft: PropTypes.string,
  iconTop: PropTypes.string
};

export default SearchBar;
