import React from 'react';
import SearchIcon from '../../assets/icons/search.svg';
const SearchIconComponent = () => {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', marginTop: '-1px' }}>
      <img
        src={SearchIcon}
        alt="Search Icon"
        style={{ width: '24px', height: '24px', marginRight: '5px', marginLeft: '0px' }}
      />
    </div>
  );
};

export default SearchIconComponent;
