// Tabs.js
import React, { useState } from 'react';

const TabList = ({ tabs }) => {
  const [activeTab, setActiveTab] = useState(tabs[0].label);

  const handleTabClick = (tab) => {
    setActiveTab(tab.label);
  };

  return (
    <div>
      <ul className="nav nav-pills mb-3">
        {tabs.map((tab) => (
          <li className="nav-item" key={tab.label}>
            <button
              className={`nav-link ${activeTab === tab.label ? 'active' : ''}`}
              onClick={() => handleTabClick(tab)}
            >
              {tab.label}
            </button>
          </li>
        ))}
      </ul>
      <div className="tab-content">
        {tabs.map((tab) => (
          <div
            key={tab.label}
            className={`tab-pane fade ${activeTab === tab.label ? 'show active' : ''}`}
          >
            {tab.content}
          </div>
        ))}
      </div>
    </div>
  );
};

export default TabList;
