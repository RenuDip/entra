// TabSlider.jsx
import React from 'react';
import '../../style/style.scss'; // Import your TabSlider styling

const TabSlider = () => {
  return (
    <div className="TabSlider"></div>
  );
};

export default TabSlider;
