import React, { useState, useEffect } from 'react';
import Pagination from "../../../src/utils/Pagination";
import AppRequestdata from "../../app/userData.json";
import NoRequestsSvg from "../../components/Shared/NoRequestsSVG";

const TableComponent = ({ columnshead, columndata, itemsPerPage, containerClass, requestType }) => {
  const [data, setData] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedRows, setSelectedRows] = useState(new Set());

  useEffect(() => {
    if (AppRequestdata && Array.isArray(AppRequestdata[requestType])) {
      setData(AppRequestdata[requestType]);
    } else {
      console.error(`${requestType} is undefined or not an array in AppRequestdata`);
      setData([]);
    }
  }, [requestType]);

  const totalPages = Math.ceil(data.length / itemsPerPage);

  const currentData = data.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handleCheckAll = (event) => {
    const newSelection = event.target.checked
      ? new Set(currentData.map(row => row.requestedFor))
      : new Set();
    setSelectedRows(newSelection);
  };

  const isChecked = (row) => selectedRows.has(row.requestedFor);

  const handleApprove = (row) => {
    console.log(`Approved ${row.requestedFor}`);
    // Implement approval logic
  };

  const handleDeny = (row) => {
    console.log(`Denied ${row.requestedFor}`);
    // Implement denial logic
  };

  const checkboxStyle = {
    display: 'flex',
    width: '32px',
    height: '32px',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: '8px',
   // border: '1px solid var(--CoolGray-20, #DDE1E6)',
    cursor: 'pointer'
  };

  return (
    <div className={containerClass} style={{ overflow: 'hidden' }}>
      <div className="table-header" style={{ overflow: 'hidden' }}>
        <table className="table table-fixed" style={{ margin: '0', padding: '0', tableLayout: 'fixed' }}>
          <thead style={{ margin: '0', width: '0' }}>
            <tr>
              <th style={{ width: '30px', paddingLeft: '5px', position: 'relative', top: '10px' }}>
                <div style={checkboxStyle}>
                  <input
                    type="checkbox"
                    style={{ width: '50px', height: '30px', borderRadius: '8px' }}
                    checked={selectedRows.size === currentData.length && currentData.length > 0}
                    onChange={handleCheckAll}
                  />
                </div>
              </th>
              {columnshead.map((column, index) => (
                <th key={index} style={{ paddingLeft: '0px', width: '115px' }}>
                  {column}
                </th>
              ))}
            </tr>
          </thead>
        </table>
      </div>
      <div className='AppsRequest-rectangle-112'></div>
      <div
        className="AppsRequest-table-body"
        style={{ overflowY: currentData.length > 0 ? 'auto' : 'hidden' }}
      >
        <table className="table table-fixed" style={{ margin: '0', padding: '0', tableLayout: 'fixed' }}>
          <tbody style={{ overflowY: currentData.length > 0 ? 'auto' : 'hidden' }}>
            {currentData.length > 0 ? (
              currentData.map((row, rowIndex) => (
                <tr key={rowIndex}>
                  <td style={{ width: '45px', paddingLeft: '0px' }}>
                    <div style={checkboxStyle}>
                      <input
                        type="checkbox"
                        style={{ width: '24px', height: '24px', borderRadius: '8px' }}
                        checked={isChecked(row)}
                        onChange={() => {
                          const updatedSelection = new Set(selectedRows);
                          if (updatedSelection.has(row.requestedFor)) {
                            updatedSelection.delete(row.requestedFor);
                          } else {
                            updatedSelection.add(row.requestedFor);
                          }
                          setSelectedRows(updatedSelection);
                        }}
                      />
                    </div>
                  </td>
                  {columndata.map((column, columnIndex) => (
                    <td key={columnIndex} style={{ padding: '4px', fontSize: '14px', width: '200px' }}>
                      <div style={{ fontSize: column.key === 'requestedFor' ? '16px' : '14px' }}>
                        {row[column.key] || 'N/A'}
                      </div>
                    </td>
                  ))}
                  <td style={{ width: '200px', textAlign: 'center' }}>
                    <button
                      className="AppsRequest-action-button approve"
                      onClick={() => handleApprove(row)}
                    >
                      Approve
                    </button>
                    <button
                      className="AppsRequest-action-button deny"
                      onClick={() => handleDeny(row)}
                    >
                      Deny
                    </button>
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan={columnshead.length + 2} style={{ textAlign: 'center' }}>
                  <div style={{ textAlign: 'center', margin: '20px auto' }}>
                    <NoRequestsSvg style={{ width: '339px', height: '242px', flexShrink: 0 }} />
                    <p style={{
                      color: 'var(--CoolGray-50, #878D96)',
                      textAlign: 'center',
                      fontFamily: 'Inter',
                      fontSize: '14px',
                      fontWeight: '500',
                      lineHeight: '110%' /* 15.4px */
                    }}>
                      There are no requests to approve.
                    </p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
      {currentData.length > 0 && (
        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={setCurrentPage}
        />
      )}
    </div>
  );
};

export default TableComponent;
