import React from "react";

const Tabs = ({ tabs }) => {
  return (
    <>
      <ul className="nav nav-pills mb-3 ms-3 mt-3" id="pills-tab" role="tablist" style={{ width: "300px" }}>
        {tabs.map((tab, index) => (
          <li className="nav-item" role="presentation" key={index}>
            <button
              className={`nav-link btn-pills ${index === 0 ? "active" : ""}`}
              id={`pills-${tab.id}-tab`}
              data-bs-toggle="pill"
              data-bs-target={`#pills-${tab.id}`}
              type="button"
              role="tab"
              aria-controls={`pills-${tab.id}`}
              aria-selected={index === 0 ? "true" : "false"}
            >
              {tab.label}
              {tab.count !== undefined && <span className="count">{tab.count}</span>}
            </button>
          </li>
        ))}
      </ul>
      <div className="tab-content" id="pills-tabContent">
        {tabs.map((tab, index) => (
          <div
            className={`tab-pane fade ${index === 0 ? "show active" : ""}`}
            id={`pills-${tab.id}`}
            role="tabpanel"
            aria-labelledby={`pills-${tab.id}-tab`}
            tabIndex="0"
            key={index}
          >
            {tab.content}
          </div>
        ))}
      </div>
    </>
  );
};

export default Tabs;
