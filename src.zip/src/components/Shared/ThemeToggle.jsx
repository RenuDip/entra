import React, { useState } from 'react';

const ThemeToggle = () => {
  const [isDarkTheme, setIsDarkTheme] = useState(false);

  const handleToggle = () => {
    setIsDarkTheme(prevTheme => !prevTheme);
    document.body.classList.toggle('dark-theme', !isDarkTheme);
  };

  return (
    <div className="theme-toggle-container">
      <span className="theme-label">Light Theme</span>
      <label className="switch">
        <input
          type="checkbox"
          checked={isDarkTheme}
          onChange={handleToggle}
        />
        <span className="slider round"></span>
      </label>
      <span className="theme-label">Dark Theme</span>
    </div>
  );
};

export default ThemeToggle;
