import React from 'react';
import UserIcon from '../../assets/icons/user.svg';
const UserIconComponent = () => {
  return (
    <div style={{ display: 'flex', alignItems: 'flex-start', marginTop: '-1px' }}>
      <img
        src={UserIcon}
        alt="User Icon"
        style={{ width: '24px', height: '24px', marginRight: '0px', marginLeft: '0px' }}
      />
    </div>
  );
};

export default UserIconComponent;
