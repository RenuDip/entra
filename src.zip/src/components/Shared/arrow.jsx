import React from 'react';

const ArrowIcon = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="32"
    height="32"
    viewBox="0 0 24 24"
    fill="none"
    style={{
      width: '24px',
      height: '24px',
      flexShrink: 0,
      ...props.style, // Allow additional styles to be passed in
    }}
    {...props} // Spread other props to allow customization
  >
    <path
      d="M8.295 16.59L12.875 12L8.295 7.41L9.705 6L15.705 12L9.705 18L8.295 16.59Z"
      fill="#878D96"
    />
  </svg>
);

export default ArrowIcon;
