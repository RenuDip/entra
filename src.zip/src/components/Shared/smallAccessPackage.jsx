import React from 'react';
import { ReactComponent as AccessPackageSvg } from '../../assets/icons/smallAccessPackage.svg';

const AccessPackageIcon = () => (
  <div className="icon-box">
    <AccessPackageSvg className="icon-svg" />
  </div>
);

export default AccessPackageIcon;
