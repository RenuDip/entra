import React from 'react';
import { ReactComponent as AppSvg } from '../../assets/icons/smallApps.svg';

const AppIcon = () => (
  <div className="icon-box">
    <AppSvg className="icon-svg" />
  </div>
);

export default AppIcon;
