import React from 'react';
import { ReactComponent as GroupSvg } from '../../assets/icons/smallGroup.svg';

const GroupIcon = () => (
  <div className="icon-box">
    <GroupSvg className="icon-svg" />
  </div>
);

export default GroupIcon;
