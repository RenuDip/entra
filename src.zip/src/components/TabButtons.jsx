import React from "react";
import { useSelector } from "react-redux";
import { ReactComponent as DownArrowIcon } from "../assets/icons/down_arrow.svg";
import { formatDate } from "../utils/formatDate";
const TabButtons = () => {
  const accessView = useSelector((state) => state.accessView.value);
  return (
    <>
      <div className="container">
        <ul
          className="nav nav-pills mb-3 ms-3 mt-3"
          id="pills-tab"
          role="tablist"
          style={{ width: "300px" }}
        >
          <li className="nav-item" role="presentation">
            <button
              className="nav-link  btn-pills"
              id="pills-home-tab"
              data-bs-toggle="pill"
              data-bs-target="#pills-home"
              type="button"
              role="tab"
              aria-controls="pills-home"
              aria-selected="true"
            >
              Active
            </button>
          </li>
          <li className="nav-item" role="presentation">
            <button
              className="nav-link btn-pills "
              id="pills-profile-tab"
              data-bs-toggle="pill"
              data-bs-target="#pills-profile"
              type="button"
              role="tab"
              aria-controls="pills-profile"
              aria-selected="false"
            >
              Requested
              <span className="count">2</span>
            </button>
          </li>
          <li className="nav-item" role="presentation">
            <button
              className="nav-link btn-pills"
              id="pills-contact-tab"
              data-bs-toggle="pill"
              data-bs-target="#pills-contact"
              type="button"
              role="tab"
              aria-controls="pills-contact"
              aria-selected="false"
            >
              Expired
            </button>
          </li>
        </ul>
        <div className="tab-content" id="pills-tabContent">
          <div
            className="tab-pane fade show active"
            id="pills-home"
            role="tabpanel"
            aria-labelledby="pills-home-tab"
            tabIndex="0"
          >
            <div className="container mt-4">
              <div
                className="accordion accordion-flush"
                id="accordionFlushExample"
              >
                {accessView.map((item, index) => (
                  <div className="accordion-item" key={item.id}>
                    <h2 className="accordion-header ps-3" id="flush-headingOne">
                      <button
                        className="accordion-button collapsed p-0"
                        type="button"
                        data-bs-toggle="collapse"
                        data-bs-target="#flush-collapseOne"
                        aria-expanded="false"
                        aria-controls="flush-collapseOne"
                      >
                        <table className="table table-borderless m-0 w-100">
                          <thead>
                            <tr className="table-Heading">
                              <th style={{ width: "20%" }}>
                                Name{" "}
                                <button className="tab-down-btn">
                                  <DownArrowIcon height={16} width={16} />
                                </button>
                              </th>
                              <th style={{ width: "40%" }}>Description </th>
                              <th style={{ width: "20%" }}>Validity</th>
                            </tr>
                          </thead>
                          <hr />
                          <tbody>
                            <tr className="table-Container tabs-serv-cont">
                              <td className="h5">
                                {item.accessPackage.displayName}
                              </td>
                              <td>
                                <p className="table-text">
                                  {item.accessPackage.description}
                                </p>
                              </td>
                              <td>
                                <div
                                  id="date-container"
                                  className="date-container"
                                >
                                  {formatDate(
                                    item.schedule.expiration.endDateTime
                                  )}
                                </div>
                              </td>
                            </tr>
                          </tbody>
                        </table>
                      </button>
                    </h2>
                    <div
                      id="flush-collapseOne"
                      className="accordion-collapse collapse"
                      aria-labelledby="flush-headingOne"
                      data-bs-parent="#accordionFlushExample"
                    >
                      <div className="accordion-body vertical-scroll">
                        <div className="card mt-3">
                          <div className="card-body">
                            <div className="d-flex justify-content-between">
                              <div>Resources</div>
                              <div>
                                <p>Canva</p>
                                <p>Marketing Resources</p>
                                <p>Company wide Marketing Professionals</p>
                              </div>
                              <div>
                                <p>Canva</p>
                                <p>Marketing Resources</p>
                                <p>Company wide Marketing Professionals</p>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div
            className="tab-pane fade ps-3"
            id="pills-profile"
            role="tabpanel"
            aria-labelledby="pills-profile-tab"
            tabIndex="0"
          >
            2 Requested data shown will be here
          </div>
          <div
            className="tab-pane fade ps-3"
            id="pills-contact"
            role="tabpanel"
            aria-labelledby="pills-contact-tab"
            tabIndex="0"
          >
            3 Expired Data
          </div>
        </div>
      </div>
    </>
  );
};

export default TabButtons;
