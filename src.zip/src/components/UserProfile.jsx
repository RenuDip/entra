import React from 'react'
import ThemeToggle from './Shared/ThemeToggle'

const UserProfile = () => {
  return (
    <>
    <div className="profile-dropBox">
        <h3>Name</h3>
        <ThemeToggle/>
        
    </div>
    </>
  )
}

export default UserProfile