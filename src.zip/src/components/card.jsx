  import React, { useState } from 'react';
  import { ReactComponent as MyAppIcon } from '../assets/icons/myApps.svg';

  const Card = ({ id, requestName, requestedBy, approvalDate, applicationType }) => {
    const [expanded, setExpanded] = useState(false);

    const toggleExpand = () => {
      setExpanded(!expanded);
    };

    return (
      <div className="card accordion-card">
        <button
          className={`btn btn-link collapsed card-button ${expanded ? 'expanded' : ''}`}
          type="button"
          onClick={toggleExpand}
          aria-expanded={expanded}
          aria-controls={`collapse${id}`}
          aria-labelledby={`heading${id}`}
        >
          <div className="card-header-content">
            <span className="icon-dash">
              <MyAppIcon className="icon-dash-svg" />
            </span>
            <div className="text-content">
              <h4 className="card-acc-title">{requestName}</h4>
              <p className="card-request">Requested by {requestedBy}</p>
              <p className="card-approve">Approve by {approvalDate}</p>
            </div>
            <span className="arrow-icon">&#10095;</span>
          </div>
        </button>
        {expanded && (
          <div id={`collapse${id}`} className="collapse show" aria-labelledby={`heading${id}`}>
            <div className="card-body">
              <p>This is custom text for card with request name: {requestName}</p>
              <p>Requested by: {requestedBy}</p>
              <p>Approval date: {approvalDate}</p>
              <p>Application Type: {applicationType}</p> {/* Display applicationType in expanded content */}
            </div>
          </div>
        )}
      </div>
    );
  };

  export default Card;
