// src/features/accessView/accessViewSlice.js
import { createSlice } from "@reduxjs/toolkit";

 const initialState = {
  value: [
    {
      packageName: "Intellectual Property Access",
      description: "Intellectual property (IP) databases for patent searches and monitoring, such as WIPO or USPTO. IP management software for tracking patents, trademarks, and copyrights. Legal services for IP protection, including patent drafting, filing, and enforcement.",
    },
    {
      packageName: "Support and Maintenance",
      description: "A collaborative group dedicated to exploring cutting-edge ideas and pushing the boundaries of custom product design and development.",
    },
    {
      packageName: "Project Management",
      description: "Customer support ticketing systems like Zendesk or Freshdesk for managing support requests. Product documentation and user manuals for customer reference.",
    },
    {
      packageName: "Quality Assurance",
      description: "Quality control software for statistical analysis and process control, like Minitab or Quality Companion. Inspection tools such as calipers, micrometers, or coordinate measuring machines (CMM). Quality management systems (QMS) documentation and procedures.",
    },
    {
      packageName: "Material Sourcing",
      description: "Suppliers for raw materials such as metals, plastics, textiles, or electronics components. Online marketplaces like Alibaba, ThomasNet, or Mouser Electronics. Material sample kits and catalogs from suppliers.",
    },
    {
      packageName: "Three level approach access Package",
      description: "This package provides a robust approval process with three hierarchical levels, ensuring thorough review and authorization before granting access.",
    },
    { packageName: "Access package for M365", description: "slack" },
    {
      packageName: "Two level approval access package",
      description: "This package offers a two-tier approval process, providing a balance between security and efficiency in granting access rights.",
    },
    {
      packageName: "Trusted Package ",
      description: " A high-security access package, the Trusted Package is designed for users or systems that require access to sensitive data or resources.",
    },

  ]
};

const accessRequestSlice = createSlice({
  name: "accessHistory",
  initialState,
  reducers: {
    // You can add other reducers here if needed
  }
});

export default accessRequestSlice.reducer;
