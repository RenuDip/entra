// src/features/accessView/accessViewSlice.js
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  value: [
    {
      id: "bd066a77-40cb-4268-9988-cd0bad73777f",
      state: "delivered",
      status: "Delivered",
      expiredDateTime: null,
      schedule: {
        startDateTime: "2024-05-30T09:45:13.397Z",
        recurrence: null,
        expiration: {
          endDateTime: "2025-05-30T09:45:13.397Z",
          duration: null,
          type: "afterDateTime"
        }
      },
      customExtensionCalloutInstances: [],
      accessPackage: {
        id: "f38f1b3d-ede6-4339-8f75-295f88847b66",
        displayName: "Birthright Access Package",
        description: "Birthright Access Package to Meta Workplace",
        isHidden: false,
        createdDateTime: "2024-05-17T06:26:08.427Z",
        modifiedDateTime: "2024-05-21T08:38:27.767Z"
      }
    },
    {
      id: "bd066a77-40cb-4268-9988-cd0bad73777f",
      state: "delivered",
      status: "Delivered",
      expiredDateTime: null,
      schedule: {
        startDateTime: "2024-05-30T09:45:13.397Z",
        recurrence: null,
        expiration: {
          endDateTime: "2025-05-30T09:45:13.397Z",
          duration: null,
          type: "afterDateTime"
        }
      },
      customExtensionCalloutInstances: [],
      accessPackage: {
        id: "f38f1b3d-ede6-4339-8f75-295f88847b66",
        displayName: "Birthright Access Package dummy",
        description: "Birthright Access Package to Meta Workplace dummy",
        isHidden: false,
        createdDateTime: "2024-05-17T06:26:08.427Z",
        modifiedDateTime: "2024-05-21T08:38:27.767Z"
      }
    },
    {
      id: "bad54f19-3566-4e99-ada6-0aa11af7eafe",
      requestType: "userAdd",
      state: "expired",
      status: "FulfilledNotificationTriggered",
      createdDateTime: "2024-08-02T09:25:50.71Z",
      completedDateTime: "2024-08-02T09:29:57.877Z",
      schedule: {
        startDateTime: null,
        recurrence: null,
        expiration: {
          endDateTime: null,
          duration: null,
          type: "notSpecified"
        }
      },
      answers: [],
      customExtensionCalloutInstances: [],
      accessPackage: {
        id: "806d503b-c90e-4898-b077-197f11472328",
        displayName: "Visio Access Package",
        description: "This is the access package for Visio",
        isHidden: false,
        createdDateTime: "2024-08-01T11:40:13.597Z",
        modifiedDateTime: "2024-08-01T11:40:13.597Z"
      }
    }
  ]
};


const accessViewSlice = createSlice({
  name: "accessView",
  initialState,
  reducers: {
    // You can add other reducers here if needed
  }
});

export default accessViewSlice.reducer;
