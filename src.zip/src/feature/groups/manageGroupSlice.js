// src/features/accessView/accessViewSlice.js
import { createSlice } from "@reduxjs/toolkit";

 const initialState = {
  value: [
    {
      name: "Anisha Giri",
      email: "anishagiri@inspiritvision.com",
      role: "Owner",
      decision: ["Remove Ownership", "Remove"],
    },
    {
      name: "Jane Doe",
      email: "JaneDoe@inspiritvision.com",
      role: "Owner",
      decision: ["Remove Ownership", "Remove"],
    },
    {
      name: "Barkha Desai",
      email: "barkha.d@inspiritvision.com",
      role: "Member",
      decision: ["Make Owner", "Remove"],
    },
    {
      name: "Biyu Huang",
      email: "biyu@inspiritvision.com",
      role: "Member",
      decision: ["Make Owner", "Remove"],
    },
    {
      name: "Grace Brown",
      email: "grace@inspiritvision.com",
      role: "Member",
      decision: ["Make Owner", "Remove"],
    },
    {
      name: "Harsha Gupta",
      email: "iharshaguptainspiritvision.com",
      role: "Member",
      decision: ["Make Owner", "Remove"],
    },
    {
      name: "May Carters",
      email: "may.c@inspiritvision.com",
      role: "Member",
      decision: ["Make Owner", "Remove"],      

    }
  ]

};

const manageGroupSlice = createSlice({
  name: "GroupManage",
  initialState,
  reducers: {
    // You can add other reducers here if needed
  }
});

export default manageGroupSlice.reducer;
