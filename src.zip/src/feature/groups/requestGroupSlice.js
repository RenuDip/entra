// src/features/accessView/accessViewSlice.js
import { createSlice } from "@reduxjs/toolkit";

 const initialState = {
  value:  [
    {
        requestFor: "APAC Sports Community",
        appName: "community of sportsperson",
        approver: "Jaya Singh",
        date: "11/02/24",
        decision: "Request",
      },
      {
        requestFor: "Art Enthusiasts ",
        appName: "Forum to discuss art-related extracurricular activities.",
        approver: "abc",
        date: "date",
        decision: "Request",
      },
      {
        requestFor: "Bespoke Solutions Alliance",
        appName:
          "A strategic partnership of experts committed to delivering customized solutions that address the specific challenges and requirements of each client.",
        approver: "Jaya Singh",
        date: "date",
        decision: "Request",
      },
      {
        requestFor: "Company Wide Events",
        appName:
          "A community of artisans and engineers passionate about crafting bespoke solutions tailored to each client's unique needs.",
        approver: "Renu Singh",
        date: "date",
        decision: "Request",
      },
      {
        requestFor: "CustomGenius Guild",
        appName:
          "For those interested in getting participation notifications for the events management team.",
        approver: "Jaya Singh",
        date: "date",
        decision: "Request",
      },
      {
        requestFor: "Design Innovators Network",
        appName:
          "A guild of experts with diverse skills and expertise, united by a shared passion for creating custom solutions that exceed expectations and drive success.",
        approver: "Jaya Singh",
        date: "date",
        decision: "Request",
      },
      {
        requestFor: "Green Thumbs",
        appName:
          "An interconnected group of designers, engineers, and innovators working together to create groundbreaking custom products that redefine industry standards.",
        approver: "Jaya Singh",
        date: "date",
        decision: "Request",
      },
      {
        requestFor: "Innovation Forge",
        appName:
          "DiscusA dynamic group dedicated to forging innovative pathways and shaping the future of custom product development through creativity, collaboration, and continuous improvement.sions on sustainability.",
        approver: "abc",
        date: "date",
        decision: "Request",
      },
  
      {
        requestFor: "Rani Patel",
        appName: "Sales Exec Manager",
        approver: "Renu Singh",
        date: "date",
        decision: "Request",
      },
      {
        requestFor: "Rani Patel",
        appName: "Sales Exec Manager",
        approver: "Renu Singh",
        date: "date",
        decision: "Request",
      },
      {
        requestFor: "Rani Patel",
        appName: "Sales Exec Manager",
        approver: "Renu Singh",
        date: "date",
        decision: "Request",
      },
   
  ],

};

const requestGroupSlice = createSlice({
  name: "GroupRequest",
  initialState,
  reducers: {
    // You can add other reducers here if needed
  }
});

export default requestGroupSlice.reducer;
