
import { createSlice } from "@reduxjs/toolkit";

 const initialState = {
  value:  [
    { groupName: "Project Management", describe: "Project management templates and guides.", type: "M365",  role: "Owner" },
    { groupName: "Innovation Junction", describe: "A collaborative group dedicated to exploring cutting-edge ideas and pushing the boundaries of custom product design and development.", type: "M365",  role: "Member" },
    { groupName: "All India Employees", describe: "Shared content for those working out of India.", type: "Security", date: "28/11/24", role: "Member" },
    { groupName: "Global Tech Team", describe: "Tech Teams across the globe.", type: "M365",  role: "Member" },
    { groupName: "Marketing Managers", describe: "APAC Marketing Managers.", type: "Security",  role: "Member" },
    { groupName: "Slack Users", describe: "Users with access to Slack.", type: "Security", date: "05/03/24", role: "Member" },
    { groupName: "Adobe Creative Cloud", describe: "Users with Access to Adobe Creative cloud.", type: "Security",  role: "Member" },
    { groupName: "Canva Creatives", describe: "Forum to share Canva tips, tricks and suggestions.", type: "M365", date: "19/04/24", role: "Member" },
    { groupName: "Adobe Creative Cloud", describe: "Marketing Essential", type: "Security", role: "Member" },
    { groupName: "APAC Marketing ", describe: "Marketing Department employees from APAC region.", type: "Security", date: "15/08/24", role: "Member" },

    { groupName: "Innovation Junction", describe: "A collaborative group dedicated to exploring cutting-edge ideas and pushing the boundaries of custom product design and development.", type: "Security",  role: "Member" }

   
  ],

};

const ViewGroupSlice = createSlice({
  name: "GroupView",
  initialState,
  reducers: {
    // You can add other reducers here if needed
  }
});

export default ViewGroupSlice.reducer;
