


import { createSlice } from "@reduxjs/toolkit";

 const initialState = {
  value:  [
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Alaysa Volko", appName: "Google Drive", approver: "Anisha Giri", date: "19/04/24", decision: "Denied" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "28/11/24", decision: "Approved" },
    { requestFor: "Rani Patel", appName: "Figma", approver: "Xiao Wangh", date: "05/07/24", decision: "Approved" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Tao Xu", appName: "zoom", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Grace Brown", appName: "Google Drive", approver: "abc", date: "19/0424", decision: "Denied" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "10/03/94", decision: "Approved" },
    { requestFor: "Rani Patel", appName: "DocusSign", approver: "Renu Singh", date: "15/08/24", decision: "Approved" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Alaysa Volko", appName: "Google Drive", approver: "abc", date: "19/04/24", decision: "Denied" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "28/11/24", decision: "Approved" },
    { requestFor: "Rani Patel", appName: "Figma", approver: "Renu Singh", date: "05/07/24", decision: "Approved" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Tao Xu", appName: "zoom", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Grace Brown", appName: "Google Drive", approver: "abc", date: "19/0424", decision: "Denied" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "10/03/94", decision: "Approved" },
    { requestFor: "Rani Patel", appName: "DocusSign", approver: "Renu Singh", date: "15/08/24", decision: "Approved" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", appName: "slack", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" }
   
]

};

const historyAppSlice = createSlice({
  name: "appHistory",
  initialState,
  reducers: {
    // You can add other reducers here if needed
  }
});

export default historyAppSlice.reducer;
