


import { createSlice } from "@reduxjs/toolkit";

 const initialState = {
  value:  [
    { appName: "Figma", description: "Powerful web-based UI Design", decision: "Request" },
    { appName: "Framer", description: "Project Manager", decision: "Request" },
    { appName: "Google Trends", description: "Sales Manager",  decision: "Request" },
    { appName: "Zendesk", description: "Sales Exec Manager", decision: "Request" },
]

};

const requestAppSlice = createSlice({
  name: "appRequest",
  initialState,
  reducers: {
    // You can add other reducers here if needed
  }
});

export default requestAppSlice.reducer;
