import { NavLink } from 'react-router-dom';

const SideNav = ({ handleSearchApps }) => {
  return (
    <div className="SideNav">
      <nav>
        <div className="row">
          <h4 className="side_nav-title ps-2 pb-1">Approvals</h4>
          <hr className="custom-hr" />

            {/* <NavLink className=" main-link non-nav-link" end>
              Overview
            </NavLink>
            <div className="nested-links">
            <NavLink className="nav-link nested-links" to="/approval/responsibilities">
              My Responsibilities
            </NavLink>

          </div> */}
        </div>
        <div className="row">

            {/* <NavLink className="non-nav-link main-link" end>
              Approve Request
            </NavLink>
            <div className="nested-links">
              <NavLink className="nav-link nested-link" to="/approval/approve-request/apps">
                Apps
                <span className='nav-count'>2</span>
              </NavLink>
              <NavLink className="nav-link nested-link" to="/approval/approve-request/groups">
                Groups
                <span className='nav-count'>17</span>
              </NavLink>
              <NavLink className="nav-link nested-link" to="/approval/approve-request/access-package">
                Access Packages
                <span className='nav-count'>5</span>
              </NavLink>

          </div> */}
        </div>
        <div className="row">

            <NavLink className="non-nav-link main-link" end>
              Review
            </NavLink>
            <div className="nested-links">
            <NavLink className="nav-link nested-links" to="/approval/access-review">

              Access Reviews
              <span className='nav-count'>2</span>
            </NavLink>
            </div>

        </div>
      </nav>
    </div>
  );
};

export default SideNav;
