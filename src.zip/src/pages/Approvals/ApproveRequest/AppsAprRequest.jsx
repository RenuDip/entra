import React from 'react'
import SideNav from '../ApprovalSideNav'
import SearchBar from "../../../components/Shared/SearchBar";
import TableComponent from "../../../components/Shared/TableComponent"
import ZoomDetection from '../../ZoomDetection';

const columnshead = ['Requested For', 'App Name', 'Requested On', 'Action'];

const columndata = [
  { label: 'Requested For', key: 'requestedFor' },
  { label: 'App Name', key: 'appName' },
  { label: 'Requested On', key: 'requestedOn' }
];

const AppsAprRequest = ({ handleSearchApps }) => {
   const handlePendingClick = () => {
    // Logic for Pending button click
    console.log('Pending button clicked');
  };

  const handleHistoryClick = () => {
    // Logic for History button click
    console.log('History button clicked');
  };
  return (
    <ZoomDetection>
  <div className="container-fluid m-0">
        <div className="row">
          <div className="col-md-2 sidebar">
            {" "}
            <SideNav />
          </div>
          <div className="col-md-10 main-container">
            <div className="border top-left-border bg-white mb-10">

                  <div className="row align-items-center pt-2">
                    <div className="rectangle-111">
                      <h1 className="rectangle-111-AppRequests">
                        App Request
                      </h1>
                      <div className="frame-66">
                      <SearchBar
                          placeholder="Search Assets..."
                          buttonLabel="0"
                          onSearch={handleSearchApps}
                          width="214px"
                          className="AppsRequest-search-bar"
                          inputClassName="custom-input"
                          buttonClassName="approval-custom-button"
                          placeholderWidth="100px"
                          searchPadding= "0"
                          iconLeft="-10px"
                          iconTop="5px"
                      />
                      <div className= "filter_alt">
                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                      <path d="M7.00506 6H17.0051L11.9951 12.3L7.00506 6ZM4.25506 5.61C6.27506 8.2 10.0051 13 10.0051 13V19C10.0051 19.55 10.4551 20 11.0051 20H13.0051C13.5551 20 14.0051 19.55 14.0051 19V13C14.0051 13 17.7251 8.2 19.7451 5.61C20.2551 4.95 19.7851 4 18.9551 4H5.04506C4.21506 4 3.74506 4.95 4.25506 5.61Z" fill="#A2A9B0"/>
                      </svg>
                      </div>
                      </div>
                      <div className="AppsRequest-Tab">
                        <button className="AppsRequest-pending-button" onClick={handlePendingClick}>
                            Pending
                        </button>
                        <button className="AppsRequest-history-button" onClick={handleHistoryClick}>
                            History
                        </button>
                      </div>
                      <button className="AppsRequest-approve-button AppsRequest-approve-button-boarder" onClick={handleHistoryClick}>
                            Approve
                      </button>
                      <button className="AppsRequest-deny-button AppsRequest-deny-button-boarder" onClick={handleHistoryClick}>
                            Deny
                      </button>
                    </div>
                    <TableComponent
                      columnshead={columnshead}
                      columndata={columndata}
                      itemsPerPage={10}
                      containerClass='AppsRequest-table-container'
                      requestType="appRequests"
                    />

                    <div className="AppsRequest-Tab"></div>
                  </div>
              </div>
          </div>
        </div>
      </div>
    </ZoomDetection>
  )
}

export default AppsAprRequest
