import React from "react";

import SideNav from "../ApprovalSideNav";
import DirectReportee from '../../../components/Shared/DirectReportee';
import Footer from "../../../components/Footer";
import TilesPage from "../../../components/Shared/DirectReporteeTile"
import ApprovalTilesPage from "../../../components/Shared/ApprovalReporteeTile"
import ApprovalReportee from '../../../components/Shared/ApprovalReportee';
import ZoomDetection from '../../ZoomDetection';

const Responsibilities = () => {
  return (
    <ZoomDetection>
    <div className="container-fluid m-0">
      <div className="row">
        <div className="col-md-2 sidebar">
          <SideNav />
        </div>
        <div className="col-md-10 rectangle main-responsibility-container ">
            <div className="container spacing responsibility-container ">
              <div className="row align-items-center pt-2 sticky-header">
                <div className="col-md-5">
                  <h1 className="mb-0 page-heading ms-3">My Responsibilities</h1>
                  <div className="info-text">
                These are the resources for which you will get Approval requests. These responsibilities can range from directly assigned or because you are part of a group. This cannot be changed.
              </div>
                </div>
                <div className="col-md-7">
                  <form className="d-flex justify-content-end">
                    {/* <button className="ms-4 entra-button" type="submit">
                      Request More
                    </button> */}
                  </form>
                </div>
              </div>
              <div class='rectangleDirectReportee'>
                   <DirectReportee />
                   <div className="rectangle103"></div>
                   <TilesPage />
                   <div className="rectangle115"></div>
              </div>
              <div class='rectangleApprovalReportee'>
                   <ApprovalReportee />
                   <div className="rectangle103"></div>
                   <ApprovalTilesPage />
                   <div className="rectangle115"></div>
              </div>
             </div>
            <Footer />
          </div>
      </div>
    </div>
    </ZoomDetection>
  );
};

export default Responsibilities;
