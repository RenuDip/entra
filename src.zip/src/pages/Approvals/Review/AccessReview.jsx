import React, { useEffect, useState } from 'react';
import SideNav from '../ApprovalSideNav';
import Footer from '../../../components/Footer';
import axios from "axios";
import { useMsal } from "@azure/msal-react";
import ZoomDetection from '../../ZoomDetection';
import GroupsAndAppsBox from '../../../components/Shared/GroupsAndApps';
import AccessPackages from '../../../components/Shared/AccessPackage';
import configData from "../../../config.json";

const AccessReview = () => {
  const [search, setSearch] = useState("");
  const [data, setData] = useState(null);
  const { instance, accounts } = useMsal();

  const fetchApi = async () => {
    console.log(configData.ENVISION_BASE_URL, "Base URL");
    try {
      const tokenResponse = await instance.acquireTokenSilent({
        scopes: ["User.Read"],
        account: accounts[0],
      });

      const response = await axios.get(
        `${configData.ENVISION_BASE_URL}/json/accessReviewDefinitionsInProgressOnReviewer`,
        {
          headers: {
            Authorization: "Bearer " + tokenResponse.accessToken,
          },
        }
      );

      console.log("API response:", response.data);
      setData(response.data);
    } catch (error) {
      console.error(
        "Error fetching data:",
        error.response ? error.response.data : error.message
      );
    }
  };


  const fetchReviewDefinitions = async () => {
    try {
      const tokenResponse = await instance.acquireTokenSilent({
        scopes: ["User.Read"],
        account: accounts[0],
      });

      const response = await axios.get(`${configData.ENVISION_BASE_URL}/json/accessReviewDefinitionsInProgressOnReviewer`, {
        headers: {
          'Authorization': 'Bearer ' + tokenResponse.accessToken
        }
      });

      console.log(response.data, "Data fetched successfully inside fetchReviewDefinitions");
      return response.data.reviewDefinitions;
    } catch (error) {
      console.error('Error fetching review definitions:', error.response ? error.response.data : error.message);
      return [];
    }
  };

  useEffect(() => {
    fetchApi();
  }, []);

  const handleSearchGroupsAndApps = (searchTerm) => {
    console.log("Searching for:", searchTerm);
  };

  return (
    <ZoomDetection>
      <div className="container-fluid m-0">
        <div className="row">
          <div className="col-md-2 sidebar">
            <SideNav />
          </div>
          <div className="col-md-10 rectangle rectangle-111">
            <div className="container spacing responsibility-container">
              <div className="row align-items-center pt-2 sticky-header">
                <div className="col-md-5">
                  <h1 className="mb-0 page-heading ms-3">Access Reviews</h1>
                  <div className="info-text"></div>
                </div>
                <div className="col-md-7">
                  <form className="d-flex justify-content-end">
                    {/* <button className="ms-4 entra-button" type="submit">
                      Request More
                    </button> */}
                  </form>
                </div>
              </div>
              <div className="rectangleGroupsAndApps">
              {console.log("Data being passed to GroupsAndAppsBox:", data)}
              <GroupsAndAppsBox
                handleSearchGroupsAndApps={handleSearchGroupsAndApps}
                fetchReviewDefinitions={fetchReviewDefinitions}
                reviewDefinitions={data ? data : []}
              />
              </div>
              <div className="rectangleAccessPackage">
                <AccessPackages />
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </ZoomDetection>
  );
};

export default AccessReview;
