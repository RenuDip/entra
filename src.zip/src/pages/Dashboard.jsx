import React, { useState, useEffect } from "react";
import DashTabs from "../components/DashTabs";
import { ReactComponent as MyAppIcon } from "../assets/icons/myApps.svg";
import { ReactComponent as HomeIcon } from "../assets/icons/access.svg";
import { ReactComponent as MyGroupIcon } from "../assets/icons/MyGroupIcon.svg";
import SearchBar from "../components/Shared/SearchBar";
import { useNavigate } from 'react-router-dom';
import Footer from "../components/Footer";
import pendingActions from "../assets/icons/pending_actions.png";
import userData from "../app/userData.json";
import CardTabs from '../components/CardTabs';
import UserIcon from '../components/Shared/UserIcon';
import UserList from '../components/UserAccessPackageRequest';
import DividerLine from '../components/Shared/Divider';
import ZoomDetection from './ZoomDetection';
import GroupList from '../components/Shared/GroupList';

const Dashboard = () => {
  const [user, setUser] = useState({ name: '', position: '' });
  const [cards, setCards] = useState([]);
  const [requests, setRequests] = useState([]);
  const [groups, setGroups] =useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredApps, setFilteredApps] = useState([]);
  const [rightContainerOpen, setRightContainerOpen] = useState(() => {
    const savedState = localStorage.getItem('rightContainerOpen');
    return savedState !== null ? JSON.parse(savedState) : false;
  });

  useEffect(() => {
    if (userData) {
      setUser(userData);
      setCards(userData.cards || []);
      setRequests(userData.requests || []);
      setGroups(userData.groups || []);
      setFilteredApps(userData.apps || []);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('rightContainerOpen', JSON.stringify(rightContainerOpen));
  }, [rightContainerOpen]);

  useEffect(() => {
    if (userData && userData.apps) {
      setFilteredApps(userData.apps.filter(app => app.name.toLowerCase().includes(searchQuery.toLowerCase())));
    }
  }, [searchQuery]);

  const navigate = useNavigate();

  const handleAddRequest = () => {
    navigate('/self-service/my-access-packages/request-app');
  };

  const handleMyGroupRequest = () => {
    navigate('/self-service/my-groups/request-new');
  };

  const handleViewAllRequest = () => {
    navigate('/self-service/my-access-packages/view');
  };

  const handleViewAllGroup = () => {
    navigate('/self-service/my-groups/view-all');
  };

  const toggleRightContainer = () => {
    setRightContainerOpen(!rightContainerOpen);
  };

  const handleSearchApps = (searchValue) => {
    setSearchQuery(searchValue);
  };

  return (
    <ZoomDetection>
    <div className="dashboard-container bg-white">
      <div className={`visible-box ${rightContainerOpen ? "open" : "close"}`} onClick={toggleRightContainer}>
        {!rightContainerOpen && (
          <div className="closed-structure">
            <div className="pendingActions-image">
              <img src={pendingActions} alt="Pending Actions" />
            </div>
            <div className="right-text">Actions</div>
          </div>
        )}
        {rightContainerOpen && (
          <button className="togglebtn">
            <span>&#10095;</span> {/* Arrow icon */}
          </button>
        )}
      </div>
      <div className={`rightContainer pt-1 ${rightContainerOpen ? "open" : ""}`}>
        <div className="rightContainer-content">
          <div className="container">
            <h1 className="MyActionPanel-Heading">My Actions</h1>
            <div className="mb-4">
              <h5 className="Approval-sub-heading">Approve Requests</h5>
              <div className="container mt-4">
                <div className="accordion" id="accordionExample">
                  <CardTabs cards={cards} />
                </div>
              </div>
            </div>
            <div>
              <h5 className="sub-heading">Conduct Access Reviews</h5>
              <div className="d-flex">
                <button className="light-button" type="submit">
                  Access Packages
                </button>
                <button className="light-button ms-2" type="submit">
                  Groups
                </button>
                <button className="light-button ms-2" type="submit">
                  Apps
                </button>
              </div>
              <h5 className="sub-heading">Scheduled Review</h5>
              <p>Completed By 06/05/2024</p>
              <div className="progress">
                <div
                  className="progress-bar"
                  role="progressbar"
                  style={{ width: "45%" }}
                  aria-valuenow="25"
                  aria-valuemin="0"
                  aria-valuemax="100"
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className={`main ${rightContainerOpen ? "shifted" : ""}`}>
        <div className="profile-bg">
          <div className="profile-dash">
            <div className={`profile-dash-background ${rightContainerOpen ? "open" : "close"}`} onClick={toggleRightContainer}></div>
            <div className="profile-icon">
              <UserIcon />
            </div>
            <div className={`Profile-details ${rightContainerOpen ? "" : "close"}`} >
              <span className="name-details">{user.name} &nbsp; &nbsp;</span> |
              <span className="position-details">&nbsp; &nbsp; {user.position}</span>
            </div>
          </div>
        </div>
        <div className="dashboard-scroll">
          <div className="row align-items-center mt-5 ms-5">
            <div className="col-md-3 col-12 ps-3 pt-4">
              <h1 className="mb-0 page-heading">
                <span className="me-3">
                  <MyAppIcon height={32} width={32} />
                </span>
                My Apps
              </h1>
            </div>
            <div className="col-md-9 col-12 pe-4">
              <form className="d-flex justify-content-end pt-4">
                <SearchBar
                  placeholder="Search Apps..."
                  buttonLabel="0"
                  onChange={handleSearchApps}
                  width="228px"
                  className="custom-search-bar"
                  inputClassName="custom-input"
                  buttonClassName="custom-button"
                />
                <button className="ms-4 me-1 entra-button-add" type="button" onClick={handleAddRequest}>
                  Add
                </button>
                <button className="ms-4 me-4 entra-button-create" type="button" onClick={handleMyGroupRequest}>
                  Create Collection
                </button>
              </form>
            </div>
          </div>
          <div>
            <DashTabs rightContainerOpen={rightContainerOpen} apps={filteredApps} />
            <div className="row p-2">
              <div className="col-md-6 col-12 p-5">
                <div className="row align-items-center row-spacing">
                  <div className="col-md-9 p-2">
                    <h1 className="mb-0 page-heading">
                      <span className="me-2">
                        <HomeIcon height={32} width={32} />
                      </span>
                      My Access Packages
                    </h1>
                  </div>
                  <div className="col-md-2 p-5">
                    <button className="entra-button" onClick={handleAddRequest}>
                      Add
                    </button>
                  </div>
                </div>
                <DividerLine/>
                <UserList items={requests} />
                <div className="col-md-12 text-center">
                  <button className="entra-button" onClick={handleViewAllRequest}>
                    View All
                    </button>
                </div>
              </div>
              <div className="col-md-6 col-12 p-5">
                <div className="row align-items-center row-spacing">
                  <div className="col-md-9 p-2">
                    <h1 className="mb-0 page-heading">
                      <span className="me-2">
                        <MyGroupIcon height={32} width={32} />
                      </span>
                      My Groups
                    </h1>
                  </div>
                  <div className="col-md-2 p-5">
                    <button className="entra-button" onClick={handleMyGroupRequest}>
                      Add
                    </button>
                  </div>
                </div>
                <DividerLine/>
                <GroupList items={groups} />
                <div className="col-md-12 text-center">
                  <button className="entra-button" onClick={handleViewAllGroup}>
                    View All
                  </button>
                </div>
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </div>
    </ZoomDetection>
  );
};

export default Dashboard;
