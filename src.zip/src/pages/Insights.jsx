import React, { useEffect, useState } from 'react';
import axios from 'axios';

const Insights = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchData = async () => {
      try {
       
        const response = await axios.get('https://graph.microsoft.com/v1.0/identityGovernance/entitlementManagement/assignmentRequests', {
          headers: {
            Authorization: `Bearer eyJ0eXAiOiJKV1QiLCJub25jZSI6InQ5YjVwTWE2a0Z0a2loeTFRY09HclQ1OFlvNkIwNHpCNk1lMWhiOTNXSmMiLCJhbGciOiJSUzI1NiIsIng1dCI6IkwxS2ZLRklfam5YYndXYzIyeFp4dzFzVUhIMCIsImtpZCI6IkwxS2ZLRklfam5YYndXYzIyeFp4dzFzVUhIMCJ9.eyJhdWQiOiIwMDAwMDAwMy0wMDAwLTAwMDAtYzAwMC0wMDAwMDAwMDAwMDAiLCJpc3MiOiJodHRwczovL3N0cy53aW5kb3dzLm5ldC8xOTU3YzYwNS03NmQ0LTQxZGMtYjM2OS1jZTFlNTA5OWFlNjUvIiwiaWF0IjoxNzE3NzYwNjY4LCJuYmYiOjE3MTc3NjA2NjgsImV4cCI6MTcxNzg0NzM2OSwiYWNjdCI6MCwiYWNyIjoiMSIsImFpbyI6IkFUUUF5LzhXQUFBQWxxMUsyTEs2Mzl6dXU2L3M5RzhTUHBpdEZhbTBTU01MejZLSGtnTTBsd0xGNktmSzZNTzRkZWxPaml5d1o2Z2wiLCJhbXIiOlsicHdkIl0sImFwcF9kaXNwbGF5bmFtZSI6IkdyYXBoIEV4cGxvcmVyIiwiYXBwaWQiOiJkZThiYzhiNS1kOWY5LTQ4YjEtYThhZC1iNzQ4ZGE3MjUwNjQiLCJhcHBpZGFjciI6IjAiLCJmYW1pbHlfbmFtZSI6IklEIiwiZ2l2ZW5fbmFtZSI6IkVudHJhIiwiaWR0eXAiOiJ1c2VyIiwiaXBhZGRyIjoiMjcuMTA3LjM3LjEwMiIsIm5hbWUiOiJFbnRyYSBJRCIsIm9pZCI6IjMwY2EyM2EwLThjN2QtNDg0Zi04OWYyLTc4NTljMTgxYWZkNSIsInBsYXRmIjoiMyIsInB1aWQiOiIxMDAzMjAwMzgxMjlBNjlBIiwicm`
          }
        });
        setData(response.data);
        setLoading(false);
      } catch (error) {
        setError(error);
        setLoading(false);
      }
    };

    fetchData();
  }, []); 

  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error.message}</div>;

  return (
    <div>
    <h1>Data from API</h1>
    {data && data.length > 0 ? (
      <ul>
        {data.map(item => (
          <li key={item.id}>
            <h2>{item.displayName}</h2>
            <p>{item.description}</p>
            <p>End Date and Time: {new Date(item.endDateTime).toLocaleString()}</p>
          </li>
        ))}
      </ul>
    ) : (
      <p>No data available</p>
    )}
  </div>
  );
};

export default Insights;
