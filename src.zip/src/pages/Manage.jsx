const Manage = () => {
  return (
    <div>Manage</div>
  )
}

export default Manage