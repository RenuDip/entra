import React, { useState, useEffect } from "react";
import SideNav from "../SelfServiceSideNav";
import SearchBar from "../../../components/Shared/SearchBar";
import { ReactComponent as HomeIcon } from "../../../assets/icons/access.svg";
import { ReactComponent as FilterIcon } from "../../../assets/icons/filter.svg";
import { ReactComponent as DownArrowIcon } from "../../../assets/icons/down_arrow.svg";
import Pagination from "../../../utils/Pagination";
import Footer from "../../../components/Footer";
import { useMsal } from "@azure/msal-react";
import axios from "axios";

import configData from "../../../config.json";

const AccessPackageHistory = () => {
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortOrder, setSortOrder] = useState("asc");
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [search, setSearch] = useState("");
  const [data, setData] = useState([]);
  const { instance, accounts } = useMsal();

  const fetchApi = async () => {
    try {
      // Initialize MSAL if required (ensure MSAL is initialized properly)
      if (!instance.getAllAccounts().length) {
        await instance.initialize();
      }

      const tokenResponse = await instance.acquireTokenSilent({
        scopes: ["User.Read"],
        account: accounts[0],
      });
      console.log("tokenResponse.accessToken :- ",tokenResponse.accessToken);

      const response = await axios.get(`${configData.ENVISION_BASE_URL}/json/accessPackageRequestHistory`, {
        headers: {
          'Authorization': 'Bearer ' + tokenResponse.accessToken
        }
      });

      setData(response.data.assignments || []);
      console.log(response.data.assignments, "Data fetched successfully");
    } catch (error) {
      console.error('Error fetching data:', error.response ? error.response.data : error.message);
    }
  };

  useEffect(() => {
    fetchApi();
    console.log(data, "useEffect triggered");
  }, []);

  const totalPages = Math.ceil(data.length / rowsPerPage);

  const sortData = () => {
    const sorted = [...data].sort((a, b) => {
      const displayNameA = a.displayName || ''; // Fallback to empty string if undefined
      const displayNameB = b.displayName || ''; // Fallback to empty string if undefined
      const comparison = displayNameA.localeCompare(displayNameB);
      return sortOrder === "asc" ? comparison : -comparison;
    });
    return sorted;
  };

  const handleSort = () => {
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };

  const sortedData = sortData();

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    setSelectAll(false);
    setSelectedRows([]);
  };

  const handleRowsPerPageChange = (rows) => {
    setRowsPerPage(rows);
    setCurrentPage(1); // Reset to first page when rows per page change
  };

  const filteredData = sortedData.filter((row) => {
    const cleanedSearch = search.replace(/\s+/g, "").trim().toLowerCase(); // Remove spaces from search input
    const cleanedAccpackageName = (row.accessPackage.displayName || '').replace(/\s+/g, "").trim().toLowerCase(); // Remove spaces from app name
    return cleanedAccpackageName.includes(cleanedSearch); // Use cleaned variables for comparison
  });

  const currentRows =
    filteredData.length > rowsPerPage
      ? filteredData.slice(
          (currentPage - 1) * rowsPerPage,
          currentPage * rowsPerPage
        )
      : filteredData;
      const formatDate = (dateString) => {
        if (!dateString) return '-'; // Return '-' if dateString is not available
        const date = new Date(dateString);
        return date.toLocaleDateString(); // Format as per your requirement
      };

  return (
    <>
      <div className="container-fluid m-0">
        <div className="row">
          <div className="col-md-2 sidebar">
            <SideNav />
          </div>
          <div className="col-md-10 main-container">
            <div className="border top-left-border bg-white mb-10">
              <div className="page-header fixed">
                <div className="row align-items-center pt-3">
                  <div className="col-md-5">
                    <h1 className="mb-0 page-heading">
                      <span className="me-3">
                        <HomeIcon height={48} width={48} />
                      </span>
                      Request History for Access Packages
                    </h1>
                  </div>
                  <div className="col-md-7 d-flex justify-content-end align-items-center">
                    <SearchBar
                      placeholder="Search Access Packages..."
                      buttonLabel="Q"
                      onChange={setSearch}
                      width="265px"
                      className="custom-search-bar"
                      inputClassName="custom-input"
                      buttonClassName="custom-button"
                    />
                    <button className="ms-3 entra-button" type="submit">
                      Visible Columns
                    </button>
                    <button className="icon-btn ms-3">
                      <FilterIcon height={20} width={20} />
                    </button>
                  </div>
                </div>
              </div>
              <div className="container p-4">
                <div className="table-container">
                  <div className="table-header fixed">
                    <table className="table table-fixed">
                      <thead>
                        <tr>
                          <th style={{ width: "15%" }}>Requested for</th>
                          <th style={{ width: "24%" }} className="ps-3">
                            Access Package Name
                            <button
                              className="tab-down-btn ps-1"
                              onClick={handleSort}
                            >
                              <DownArrowIcon />
                            </button>
                          </th>
                          <th style={{ width: "18%" }}>Approver</th>
                          <th>Date</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                    </table>
                    <div className="divider"></div>
                  </div>
                  <div className="table-body">
                    <table className="table table-fixed">
                      <tbody>

                        {currentRows.map((row, index) => (

                          <tr key={index}>
                            <td style={{ width: "16%" }}>My Self</td>
                            <td>{row.accessPackage.displayName}</td>
                            <td className="text-center" style={{ width: "12%" }}>{  (row.primaryReviewers && row.primaryReviewers.length > 0)
        ? row.primaryReviewers[0].description
        : '-'}</td>
                            <td className="text-center">{formatDate(row.schedule.expiration.endDateTime)}</td>
                            <td className="text-center">
                              <button
                                className="entra-button"
                              >
                                {row.status}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="pt-2">
                  {data.length > 0 && (
                    <Pagination
                      currentPage={currentPage}
                      totalPages={totalPages}
                      onPageChange={handlePageChange}
                      onRowsPerPageChange={handleRowsPerPageChange}
                    />
                  )}
                </div>
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </>
  );
};

export default AccessPackageHistory;
