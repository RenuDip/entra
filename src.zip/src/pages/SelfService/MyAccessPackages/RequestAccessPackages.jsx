import React, { useState } from "react";
import { useSelector } from "react-redux";
import SideNav from "../SelfServiceSideNav";
import SearchBar from "../../../components/Shared/SearchBar";
import Footer from "../../../components/Footer";
import Pagination from "../../../utils/Pagination";

import RequestModal from "../../../components/Shared/RequestModal";

import { ReactComponent as CompanyIcon } from "../../../assets/icons/group.svg";
import { ReactComponent as LanguageIcon } from "../../../assets/icons/language.svg";
import { ReactComponent as ComputerIcon } from "../../../assets/icons/computer.svg";
import { ReactComponent as HomeIcon } from "../../../assets/icons/access.svg";
import { ReactComponent as FilterIcon } from "../../../assets/icons/filter.svg";
import { ReactComponent as DownArrowIcon } from "../../../assets/icons/down_arrow.svg";
import { ReactComponent as UpArrowIcon } from "../../../assets/icons/acc-up-arrow.svg";
import { ReactComponent as DownAccIcon } from "../../../assets/icons/acc-down-arrow.svg";

const RequestAccessPackages = () => {
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [expandedRow, setExpandedRow] = useState(null);
  const [requiredForPeriod, setRequiredForPeriod] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortOrder, setSortOrder] = useState("asc");
    const [formState, setFormState] = useState({});
  const [buttonText, setButtonText] = useState({});
  const [showMessage, setShowMessage] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [search, setSearch] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const toggleRow = (index) => {
    setExpandedRow(expandedRow === index ? null : index);
  };




  const handleSelectChange = (selected) => {
    setSelectedOptions(selected);
  };

  const handleToggle = () => {
    setRequiredForPeriod(!requiredForPeriod);
  };

  const handleJustificationChange = (index, event) => {
    setFormState((prevState) => ({
      ...prevState,
      [index]: {
        ...prevState[index],
        businessJustification: event.target.value,
      },
    }));
  };

  const handleSubmit = (index) => {
    const formData = formState[index];
    if (!formData || !formData.businessJustification) {
      setErrorMessage("Business Justification is required.");
      return;
    }
    console.log("Form Data Submitted:", formData);
    setButtonText((prevState) => ({
      ...prevState,
      [index]: "Requested",
    }));
    setShowMessage(true);
    setErrorMessage("");
    setTimeout(() => setShowMessage(false), 2500);
    document.querySelector(`#modal${index} .btn-close`).click();
  };



  const options = [
    { value: "name1", label: "Name 1" },
    { value: "name2", label: "Name 2" },
    { value: "name3", label: "Name 3" },
    { value: "name4", label: "Name 4" },
    { value: "name5", label: "Name 5" },
    { value: "name6", label: "Name 6" },
  ];

  const data = useSelector((state) => state.accessrequest.value);

  const totalPages = Math.ceil(data.length / rowsPerPage);


  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const sortData = () => {
    const sorted = [...data].sort((a, b) => {
      const comparison = a.packageName.localeCompare(b.packageName);
      return sortOrder === "asc" ? comparison : -comparison;
    });
    return sorted;
  };

  const handleSort = () => {
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };

  const sortedData = sortData();
  const handleRowsPerPageChange = (rows) => {
    setRowsPerPage(rows);
    setCurrentPage(1); // Reset to first page when rows per page change
  };
  const filteredData = sortedData.filter((row) => {
    
    const cleanedSearch = search.replace(/\s+/g, "").trim().toLowerCase();  // Remove spaces from search input
    const cleanedpackageName = row.packageName.replace(/\s+/g, "").trim().toLowerCase();  // Remove spaces from app name
    return cleanedpackageName.includes(cleanedSearch);  // Use cleaned variables for comparison
  });

  const currentRows =
  filteredData.length > rowsPerPage
      ? filteredData.slice(
          (currentPage - 1) * rowsPerPage,
          currentPage * rowsPerPage
        )
      : filteredData;
     
  return (
    <>
      <div className="container-fluid m-0 content">
        <div className="row">
          <div className="col-md-2 sidebar">
            <SideNav />
          </div>
          <div className="col-md-10 main-container">
            <div className="border top-left-border bg-white">
              <div className="page-header fixed">
                <div className="row align-items-center pt-3">
                  <div className="col-md-5">
                    <h1 className="mb-0 page-heading">
                      <span className="me-3">
                        <HomeIcon height={48} width={48} />
                      </span>
                      Request Access Packages
                    </h1>
                  </div>
                  <div className="col-md-7 d-flex justify-content-end align-items-center">
                    <SearchBar
                      placeholder="Search Access Packages..."
                      buttonLabel="Q"
                      onChange={(e) => setSearch(e.target.value)}
                      width="265px"
                      className="custom-search-bar"
                      inputClassName="custom-input"
                      buttonClassName="custom-button"
                    />
                    <button className="icon-btn ms-3">
                      <FilterIcon height={20} width={20} />
                    </button>
                  </div>
                </div>
              </div>
              <div className="container p-4">
                <div className="table-container">
                  <div className="table-header fixed">
                    <table className="table table-fixed">
                      <thead>
                        <tr>
                          <th style={{ width: "21.5%" }}>
                            Name
                            <button className="tab-down-btn" onClick={handleSort}>
                              <DownArrowIcon />
                            </button>
                          </th>
                          <th>Description</th>
                          <th></th>
                          <th></th>
                        </tr>
                      </thead>
                    </table>
                    <div className="divider"></div>
                  </div>

                  <div className="table-body">
                    <table className="table table-fixed">
                      <tbody id="hight-table">
                        {currentRows.map((row, index) => (
                          <React.Fragment key={index}>
                            <tr className="p-4">
                              <td className="h5" style={{ width: "22%" }}>{row.packageName}</td>
                              <td style={{ width: "56%" }} className="pb-4">
                                {row.description}
                              </td>
                              <td className="text-center" style={{ width: "15%" }}>
                              <button
                                className="entra-button"
                                data-bs-toggle={
                                  buttonText[index] !== "Requested"
                                    ? "modal"
                                    : ""
                                }
                                data-bs-target={`#modal${index}`}
                              >
                                {buttonText[index] || "Request"}
                              </button>
                              {buttonText[index] !== "Requested" && (
                                <RequestModal
                                  index={index}
                                  row={row}
                                  modalTitle={row.packageName}
                                  requiredForPeriod={requiredForPeriod}
                                  handleToggle={handleToggle}
                                  selectedOptions={selectedOptions}
                                  handleSelectChange={handleSelectChange}
                                  formState={formState}
                                  handleJustificationChange={
                                    handleJustificationChange
                                  }
                                  handleSubmit={handleSubmit}
                                  options={options}
                                  errorMessage={errorMessage}
                                />
                              )}
                              </td>
                              <td className="text-center" style={{ width: "7%" }}>
                                <button className="border-0 bg-white" onClick={() => toggleRow(index)}>
                                  {expandedRow === index ? <UpArrowIcon /> : <DownAccIcon />}
                                </button>
                              </td>
                            </tr>
                            {expandedRow === index && (
                               <tr className="accordion-content">
                               <td colSpan="4">
                               <div className="d-flex justify-content-between">
                                 <div>Resources</div>
                                 <div>
                                   <p> <ComputerIcon/><span className="ms-2">Canva</span></p>
                                   <p><LanguageIcon/><span className="ms-2">Marketing Resources</span></p>
                                   <p><CompanyIcon /><span className="ms-2">Company wide Marketing Professionals</span></p>
                                 </div>
                                 <div>
                                   <p> <ComputerIcon/><span className="ms-2">Canva</span></p>
                                   <p><LanguageIcon/><span className="ms-2">Marketing Resources</span></p>
                                   <p><CompanyIcon /><span className="ms-2">Company wide Marketing Professionals</span></p>
                                 </div>
                               </div>
                               </td>
                             </tr>
                            )}
                          </React.Fragment>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                {showMessage && (
                  <div className="alert alert-success" role="alert">
                    Your request has been submitted.
                  </div>
                )}
            
                {totalPages > 0 && (
                  <Pagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={handlePageChange}
                    onRowsPerPageChange={handleRowsPerPageChange}
                
                  />
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};




export default RequestAccessPackages;
