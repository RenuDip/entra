import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import SideNav from "../SelfServiceSideNav";
import SearchBar from "../../../components/Shared/SearchBar";
import Footer from "../../../components/Footer";
import { ReactComponent as CompanyIcon } from "../../../assets/icons/group.svg";
import { ReactComponent as LanguageIcon } from "../../../assets/icons/language.svg";
import { ReactComponent as ComputerIcon } from "../../../assets/icons/computer.svg";
import { ReactComponent as HomeIcon } from "../../../assets/icons/access.svg";
import { ReactComponent as DownAccIcon } from "../../../assets/icons/acc-down-arrow.svg";
import { ReactComponent as UpArrowIcon } from "../../../assets/icons/acc-up-arrow.svg";
import { ReactComponent as DownArrowIcon } from "../../../assets/icons/down_arrow.svg";
import { formatDate } from "../../../utils/formatDate";
import Pagination from "../../../utils/Pagination";
import axios from "axios";
import { useMsal } from "@azure/msal-react";
import configData from "../../../config.json";

const ViewAccessPackages = () => {
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [activeTab, setActiveTab] = useState('pills-home');
  const [expandedRow, setExpandedRows] = useState({
    "pills-home": null,
    "pills-profile": null,
    "pills-contact": null,
  });
  const [jsonData, setData] = useState([]);
  const { instance, accounts } = useMsal();

  const handleRequest = () => {
    navigate('/self-service/my-access-packages/request-app');
  };

  const handleSearch = () => {
    console.log("Search button clicked");
  };

  const fetchApi = async () => {
    console.log(configData.ENVISION_BASE_URL, "Base URL");
    try {
      const tokenResponse = await instance.acquireTokenSilent({
        scopes: ["User.Read"],
        account: accounts[0],
      });

      const response = await axios.get(
        `${configData.ENVISION_BASE_URL}/json/myActiveAccessPackage`,
        {
          headers: {
            Authorization: "Bearer " + tokenResponse.accessToken,
          },
        }
      );

      console.log("API response:", response.data);

      // Ensure we're setting the data to an array
      setData(Array.isArray(response.data.assignments) ? response.data.assignments : []);
    } catch (error) {
      console.error(
        "Error fetching data:",
        error.response ? error.response.data : error.message
      );
    }
  };



  useEffect(() => {
    fetchApi();
  }, [instance, accounts]);
  useEffect(() => {
  console.log("jsonData state updated:", jsonData);
}, [jsonData]);
const currentData = jsonData;

  const totalPages = Math.ceil(currentData.length / rowsPerPage);

  // Handle page change
  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const handleRowsPerPageChange = (rows) => {
    setRowsPerPage(rows);
    setCurrentPage(1); // Reset to first page
  };

  const toggleRow = (index) => {
    setExpandedRows(prevState => ({
      ...prevState,
      [activeTab]: prevState[activeTab] === index ? null : index
    }));
  };

  // const renderTableRows = (data) => {
  //   return data.length > 0 ? (
  //     data.map((value, i) => (
  //       <React.Fragment key={i}>
  //         <tr className="p-2">
  //           <td className="h5" style={{ width: "26%" }}>
  //             {value.accessPackage.displayName}
  //           </td>
  //           <td style={{ width: "40%" }}>
  //             {value.accessPackage.description}
  //           </td>
  //           <td style={{ width: "18%" }}>
  //             {formatDate(value.schedule.expiration.endDateTime)}
  //           </td>
  //           <td onClick={() => toggleRow(i)}>
  //             <button className="btn-transp">
  //               {expandedRow[activeTab] === i ? <UpArrowIcon /> : <DownAccIcon />}
  //             </button>
  //           </td>
  //         </tr>
  //         {expandedRow[activeTab] === i && (
  //           <tr className="accordion-content">
  //             <td colSpan="4">
  //               <div className="d-flex justify-content-between">
  //                 <div>Resources</div>
  //                 <div>
  //                   <p><ComputerIcon /><span className="ms-2">Canva</span></p>
  //                   <p><LanguageIcon /><span className="ms-2">Marketing Resources</span></p>
  //                   <p><CompanyIcon /><span className="ms-2">Company wide Marketing Professionals</span></p>
  //                 </div>
  //                 <div>
  //                   <p><ComputerIcon /><span className="ms-2">Canva</span></p>
  //                   <p><LanguageIcon /><span className="ms-2">Marketing Resources</span></p>
  //                   <p><CompanyIcon /><span className="ms-2">Company wide Marketing Professionals</span></p>
  //                 </div>
  //               </div>
  //             </td>
  //           </tr>
  //         )}
  //       </React.Fragment>
  //     ))
  //   ) : (
  //     <tr>
  //       <td colSpan="4" className="text-center">
  //         No data available
  //       </td>
  //     </tr>
  //   );
  // };


  // const renderTableRows = (data) => {
  //   return data.length > 0 ? (
  //     data.map((value, i) => (
  //       <React.Fragment key={i}>
  //         <tr className="p-2">
  //           <td className="h5" style={{ width: "26%" }}>
  //             {value.displayName}
  //           </td>
  //           <td style={{ width: "40%" }}>
  //             {value.description}
  //           </td>
  //           <td style={{ width: "18%" }}>
  //             {formatDate(value.endDateTime)}
  //           </td>
  //           <td onClick={() => toggleRow(i)}>
  //             <button className="btn-transp">
  //               {expandedRow[activeTab] === i ? <UpArrowIcon /> : <DownAccIcon />}
  //             </button>
  //           </td>
  //         </tr>
  //         {expandedRow[activeTab] === i && (
  //           <tr className="accordion-content">
  //             <td colSpan="4">
  //               <div className="d-flex justify-content-between">
  //                 <div>Resources</div>
  //                 <div>
  //                   <p><ComputerIcon /><span className="ms-2">Canva</span></p>
  //                   <p><LanguageIcon /><span className="ms-2">Marketing Resources</span></p>
  //                   <p><CompanyIcon /><span className="ms-2">Company wide Marketing Professionals</span></p>
  //                 </div>
  //                 <div>
  //                   <p><ComputerIcon /><span className="ms-2">Canva</span></p>
  //                   <p><LanguageIcon /><span className="ms-2">Marketing Resources</span></p>
  //                   <p><CompanyIcon /><span className="ms-2">Company wide Marketing Professionals</span></p>
  //                 </div>
  //               </div>
  //             </td>
  //           </tr>
  //         )}
  //       </React.Fragment>
  //     ))
  //   ) : (
  //     <tr>
  //       <td colSpan="4" className="text-center">
  //         No data available
  //       </td>
  //     </tr>
  //   );
  // };
  const renderTableRows = (data) => {

    return data.length > 0 ? (

      data.map((value, i) => (
        <React.Fragment key={i}>
          <tr className="p-2">
            <td className="h5" style={{ width: "26%" }}>
              {value.displayName}
            </td>
            <td style={{ width: "40%" }}>
              {value.description}
            </td>
            <td style={{ width: "18%" }}>
              {formatDate(value.endDateTime)}
            </td>
            <td>
              <button className="btn-transp" onClick={() => toggleRow(i)}>
                {expandedRow[activeTab] === i ? <UpArrowIcon /> : <DownAccIcon />}
              </button>
            </td>
          </tr>
        </React.Fragment>
      ))
    ) : (
      <tr>
        <td colSpan="4" className="text-center">
          No data available
        </td>
      </tr>
    );
  };

  useEffect(() => {
    // Scroll to top whenever the active tab changes
    window.scrollTo(0, 0);
  }, [activeTab]);

  return (
    <div className="container-fluid m-0">
      <div className="row">
        <div className="col-md-2 sidebar">
          <SideNav />
        </div>
        <div className="col-md-10 main-container">
          <div className="border top-left-border bg-white mb-10">
            <div className="page-header fixed">
              <div className="row align-items-center pt-3">
                <div className="col-md-5">
                  <h1 className="mb-0 page-heading">
                    <span className="me-3">
                      <HomeIcon height={48} width={48} />
                    </span>
                    My Access Packages
                  </h1>
                </div>
                <div className="col-md-7">
                  <form className="d-flex justify-content-end">
                    <SearchBar
                      placeholder="Search Access Packages..."
                      buttonLabel="Q"
                      onSearch={handleSearch}
                      width="280px"
                      className="custom-search-bar"
                      inputClassName="custom-input"
                      buttonClassName="custom-button"
                    />
                    <button
                      className="ms-4 entra-button"
                      type="button"
                      onClick={handleRequest}
                    >
                      Request More
                    </button>
                  </form>
                </div>
              </div>

              <ul
                className="nav nav-pills mb-3 ms-3 mt-3"
                id="pills-tab"
                role="tablist"
                style={{ width: "332px", height: "40px" }}
              >
                <li className="nav-item" role="presentation">
                  <button
                    className={`nav-link ${activeTab === 'pills-home' ? 'active' : ''} btn-pills`}
                    id="pills-home-tab"
                    data-bs-toggle="pill"
                    data-bs-target="#pills-home"
                    type="button"
                    role="tab"
                    aria-controls="pills-home"
                    aria-selected={activeTab === 'pills-home'}
                    onClick={() => setActiveTab('pills-home')}
                  >
                    Active
                  </button>
                </li>
                <li className="nav-item" role="presentation">
                  <button
                    className={`nav-link ${activeTab === 'pills-profile' ? 'active' : ''} btn-pills`}
                    id="pills-profile-tab"
                    data-bs-toggle="pill"
                    data-bs-target="#pills-profile"
                    type="button"
                    role="tab"
                    aria-controls="pills-profile"
                    aria-selected={activeTab === 'pills-profile'}
                    onClick={() => setActiveTab('pills-profile')}
                  >
                    Requested
                    <span className="count">{jsonData.length}</span>
                  </button>
                </li>
                <li className="nav-item" role="presentation">
                  <button
                    className={`nav-link ${activeTab === 'pills-contact' ? 'active' : ''} btn-pills`}
                    id="pills-contact-tab"
                    data-bs-toggle="pill"
                    data-bs-target="#pills-contact"
                    type="button"
                    role="tab"
                    aria-controls="pills-contact"
                    aria-selected={activeTab === 'pills-contact'}
                    onClick={() => setActiveTab('pills-contact')}
                  >
                    Expired
                  </button>
                </li>
              </ul>

            </div>
            <div className="tab-content tabs-table-head" id="pills-tabContent" style={{position: "relative", top: "167px", left: "50px"}}>
              <div
                className={`tab-pane fade ${activeTab === 'pills-home' ? 'show active' : ''}`}
                id="pills-home"
                role="tabpanel"
                aria-labelledby="pills-home-tab"
              >
                <table className="table table-striped">
                  <thead>
                    <tr>
                    <th style={{ width: "25%" }}>
                              Name
                              <button className="tab-down-btn">
                                <DownArrowIcon />
                              </button>
                            </th>
                            <th style={{ width: "38%" }}>Description</th>
                            <th>Validity</th>
                            <th></th>
                    </tr>
                  </thead>
                  <div className="divider" style={{width :"382%"}}></div>
                  <tbody>
                    {renderTableRows(currentData.slice(
                      (currentPage - 1) * rowsPerPage,
                      currentPage * rowsPerPage
                    ))}
                  </tbody>
                </table>
                <Pagination
                  currentPage={currentPage}
                  totalPages={totalPages}
                  onPageChange={handlePageChange}
                  onRowsPerPageChange={handleRowsPerPageChange}
                />
              </div>
            </div>
          </div>
          <Footer />
        </div>
      </div>
    </div>
  );
};

export default ViewAccessPackages;
