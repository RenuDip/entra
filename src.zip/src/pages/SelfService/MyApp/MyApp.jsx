import React, { useEffect, useState } from 'react';
import SideNav from "../SelfServiceSideNav";
import Footer from "../../../components/Footer";
import SearchBar from "../../../components/Shared/SearchBar";
import { ReactComponent as MyAppIcon } from "../../../assets/icons/myApps.svg";
import MyAppList from '../../../components/Shared/MyAppList';
import axios from "axios";
import { useMsal } from "@azure/msal-react";
import configData from "../../../config.json";

const MyApp = () => {
  const [search, setSearch] = useState("");
  const [data, setData] = useState("");
  const { instance, accounts } = useMsal();

  const fetchApi = async () => {
    try {
    
      const tokenResponse = await instance.acquireTokenSilent({
        scopes: ["User.Read"],
        account: accounts[0],
      });
  
      const response = await axios.get(`${configData.ENVISION_BASE_URL}/json/allTenantApplications`, {
        headers: {
          'Authorization': 'Bearer ' + tokenResponse.accessToken
        }
      });
  
      setData(response.data);
      console.log(response.data, "Data fetched successfully");
    } catch (error) {
      console.error('Error fetching data:', error.response ? error.response.data : error.message);
    }
  };
  

  useEffect(() => {
    fetchApi();
  },[]);

  return (
    <>
      <div className="container-fluid m-0">
        <div className="row">
          <div className="col-md-2 sidebar">
            <SideNav />
          </div>
          <div className="col-md-10 main-container">
            <div className="border top-left-border bg-white mb-10">
              <div className="page-header fixed">
                <div className="row align-items-center pt-3">
                  <div className="col-md-5">
                    <h1 className="mb-0 page-heading">
                      <span className="me-3">
                        <MyAppIcon height={48} width={48} />
                      </span>
                      My Apps
                    </h1>
                  </div>
                  <div className="col-md-7 d-flex justify-content-end align-items-center">
                    <SearchBar
                      placeholder="Search Apps..."
                      buttonLabel="Q"
                      onChange={setSearch}
                      width="230px"
                      className="custom-search-bar"
                      inputClassName="custom-input"
                      buttonClassName="custom-button"
                    />
                    <button className='entra-button ms-4'>Add</button>
                    <button className='entra-button ms-4'>Create Collection</button>
                  </div>
                </div>
              </div>
              <div className='container p-4 mt-3'>
                <MyAppList search={search} data={data} />
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </>
  );
};

export default MyApp;
