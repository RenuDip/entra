import React, { useState } from "react";
import { useSelector } from "react-redux";
import SideNav from "../SelfServiceSideNav";
import SearchBar from "../../../components/Shared/SearchBar";
import { ReactComponent as MyAppIcon } from "../../../assets/icons/myApps.svg";
import { ReactComponent as DownArrowIcon } from "../../../assets/icons/down_arrow.svg";
import { ReactComponent as FilterIcon } from "../../../assets/icons/filter.svg";
import { ReactComponent as FigmaIcon } from "../../../assets/icons/figma.svg";
import Footer from "../../../components/Footer";
import Pagination from "../../../utils/Pagination";
import RequestModal from "../../../components/Shared/RequestModal";

const RequestApp = () => {
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [requiredForPeriod, setRequiredForPeriod] = useState(false);
  const [formState, setFormState] = useState({});
  const [buttonText, setButtonText] = useState({});
  const [showMessage, setShowMessage] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [search, setSearch] = useState("");
  const [sortOrder, setSortOrder] = useState("asc");
  const [currentPage, setCurrentPage] = useState(1);

  const [rowsPerPage, setRowsPerPage] = useState(10);
 

  const handleSelectChange = (selected) => {
    setSelectedOptions(selected);
  };

  const handleToggle = () => {
    setRequiredForPeriod(!requiredForPeriod);
  };

  const handleJustificationChange = (index, event) => {
    setFormState((prevState) => ({
      ...prevState,
      [index]: {
        ...prevState[index],
        businessJustification: event.target.value,
      },
    }));
  };

  const handleSubmit = (index) => {
    const formData = formState[index];
    if (!formData || !formData.businessJustification) {
      setErrorMessage("Business Justification is required.");
      return;
    }
    console.log("Form Data Submitted:", formData);
    setButtonText((prevState) => ({
      ...prevState,
      [index]: "Requested",
    }));
    setShowMessage(true);
    setErrorMessage("");
    setTimeout(() => setShowMessage(false), 7889000);
    document.querySelector(`#modal${index} .btn-close`).click();
  };

  const options = [
    { value: "name1", label: "Name 1" },
    { value: "name2", label: "Name 2" },
    { value: "name3", label: "Name 3" },
    { value: "name4", label: "Name 4" },
    { value: "name5", label: "Name 5" },
    { value: "name6", label: "Name 6" },
  ];

  const data = useSelector((state) => state.requestApp.value);

  const totalPages = Math.ceil(data.length / rowsPerPage);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const sortData = () => {
    const sorted = [...data].sort((a, b) => {
      const comparison = a.appName.localeCompare(b.appName);
      return sortOrder === "asc" ? comparison : -comparison;
    });
    return sorted;
  };

  const handleSort = () => {
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };

  const sortedData = sortData();


  const filteredData = sortedData.filter((row) => {
    
    const cleanedSearch = search.replace(/\s+/g, "").trim().toLowerCase();  // Remove spaces from search input
    const cleanedAppName = row.appName.replace(/\s+/g, "").trim().toLowerCase();  // Remove spaces from app name
    return cleanedAppName.includes(cleanedSearch);  // Use cleaned variables for comparison
  });
  const handleRowsPerPageChange = (rows) => {
    setRowsPerPage(rows);
    setCurrentPage(1); // Reset to first page when rows per page change
  };

  const currentRows =
    filteredData.length > rowsPerPage
      ? filteredData.slice(
          (currentPage - 1) * rowsPerPage,
          currentPage * rowsPerPage
        )
      : filteredData;

  return (
    <>
      <div className="container-fluid m-0">
        <div className="row">
          <div className="col-md-2 sidebar">
            <SideNav />
          </div>
          <div className="col-md-10 main-container">
            <div className="border top-left-border bg-white mb-10">
              <div className="page-header fixed">
                <div className="row align-items-center pt-3">
                  <div className="col-md-5">
                    <h1 className="mb-0 page-heading">
                      <span className="me-3">
                        <MyAppIcon height={48} width={48} />
                      </span>
                      Request Apps
                    </h1>
                  </div>
                  <div className="col-md-7 d-flex justify-content-end align-items-center">
                    <SearchBar
                      placeholder="Search Apps..."
                      onChange={(e) => setSearch(e.target.value)}
                      width="250px"
                      className="custom-search-bar"
                      inputClassName="custom-input"
                      buttonClassName="custom-button"
                    />
                    <button className="icon-btn ms-3">
                      <FilterIcon height={18} width={18} />
                    </button>
                  </div>
                </div>
              </div>
              <div className="container p-4">
                <div className="table-container">
                  <div className="table-header fixed">
                    <table className="table table-fixed">
                      <thead>
                        <tr>
                          <th>
                            Name{" "}
                            <button
                              className="tab-down-btn"
                              onClick={handleSort}
                            >
                              <DownArrowIcon />
                            </button>
                          </th>
                          <th>Description</th>
                          <th></th>
                        </tr>
                      </thead>
                    </table>
                    <div className="divider"></div>
                  </div>
                  <div className="table-body">
                    <table className="table table-fixed">
                      <tbody>
                        {currentRows.length > 0 ? (
                          currentRows.map((row, index) => (
                            <tr key={index}>
                              <td className="h5">
                                <FigmaIcon className="me-3" />
                                {row.appName}
                              </td>
                              <td className="p-2">{row.description}</td>
                              <td>
                                <button
                                  className="entra-button"
                                  data-bs-toggle={
                                    buttonText[index] !== "Requested"
                                      ? "modal"
                                      : ""
                                  }
                                  data-bs-target={`#modal${index}`}
                                >
                                  {buttonText[index] || "Request"}
                                </button>
                                {buttonText[index] !== "Requested" && (
                                  <RequestModal
                                    index={index}
                                    row={row}
                                    requiredForPeriod={requiredForPeriod}
                                    handleToggle={handleToggle}
                                    selectedOptions={selectedOptions}
                                    handleSelectChange={handleSelectChange}
                                    formState={formState}
                                    handleJustificationChange={
                                      handleJustificationChange
                                    }
                                    handleSubmit={handleSubmit}
                                    options={options}
                                    errorMessage={errorMessage}
                                  />
                                )}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan="3" className="text-center">
                              No Record found.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
                {showMessage && (
                  <div className="alert alert-success" role="alert">
                    Your request has been submitted.
                  </div>
                )}
               
                <div className="pt-4">
                  {filteredData.length > 0  && (
                    <Pagination
                      currentPage={currentPage}
                      totalPages={totalPages}
                      onPageChange={handlePageChange}
                      onRowsPerPageChange={handleRowsPerPageChange}
                    />
                  )}
                </div>
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </>
  );
};

export default RequestApp;
