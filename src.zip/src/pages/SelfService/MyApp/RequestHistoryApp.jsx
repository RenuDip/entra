import React, { useState, useEffect } from "react";
import { useSelector } from "react-redux";
import SideNav from "../SelfServiceSideNav";
import Footer from "../../../components/Footer";
import SearchBar from "../../../components/Shared/SearchBar";
import { ReactComponent as MyAppIcon } from "../../../assets/icons/myApps.svg";
import { ReactComponent as FilterIcon } from "../../../assets/icons/filter.svg";
import { ReactComponent as DownArrowIcon } from "../../../assets/icons/down_arrow.svg";
import Pagination from "../../../utils/Pagination";
import { useMsal } from "@azure/msal-react";
import axios from "axios";

const RequestHistoryApp = () => {
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortOrder, setSortOrder] = useState("asc");
  const [search, setSearch] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const { instance, accounts } = useMsal();
  const [dataresponse, setDataResponse] = useState("");


  //const data = useSelector((state) => state.HistoryApp.value);
  const fetchApi = async () => {
    try {
    
      const tokenResponse = await instance.acquireTokenSilent({
        scopes: ["User.Read"],
        account: accounts[0],
      });
  
      const response = await axios.get("http://localhost:8081/json/allTenantApplications", {
        headers: {
          'Authorization': 'Bearer ' + tokenResponse.accessToken
        }
      });
  
      setDataResponse(response.data);
      console.log(response.data, "Data fetched successfully");
    } catch (error) {
      console.error('Error fetching data:', error.response ? error.response.data : error.message);
    }
  };
  

  useEffect(() => {
    console.log('RequestHistoryApp mounted');
    fetchApi();
  }, []);
  ;

  const sortData = () => {
    const sorted = [...dataresponse].sort((a, b) => {
      const comparison = a.requestFor.localeCompare(b.requestFor);
      return sortOrder === "asc" ? comparison : -comparison;
    });
    return sorted;
  };

  const handleSort = () => {
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };

  const sortedData = sortData();
  const filteredData = sortedData.filter((row) => {
    const cleanedSearch = search.replace(/\s+/g, " ").trim().toLowerCase();
    const cleanedAppName = row.appName.replace(/\s+/g, " ").trim().toLowerCase();
    return cleanedAppName.includes(cleanedSearch);
  });

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    setSelectAll(false);
    setSelectedRows([]);
  };

  const handleRowsPerPageChange = (newRowsPerPage) => {
    setRowsPerPage(newRowsPerPage);
    setCurrentPage(1); // Reset to first page when rows per page change
  };

  const totalPages = Math.ceil(filteredData.length / rowsPerPage);

  const currentRows =
    filteredData.length > rowsPerPage
      ? filteredData.slice(
          (currentPage - 1) * rowsPerPage,
          currentPage * rowsPerPage
        )
      : filteredData;

  return (
    <>
      <div className="container-fluid m-0">
        <div className="row">
          <div className="col-md-2 sidebar">
            <SideNav />
          </div>
          <div className="col-md-10 main-container">
            <div className="border top-left-border bg-white mb-10">
              <div className="page-header fixed">
                <div className="row align-items-center pt-3">
                  <div className="col-md-5">
                    <h1 className="mb-0 page-heading">
                      <span className="me-3">
                        <MyAppIcon height={48} width={48} />
                      </span>
                      Request History for Apps
                    </h1>
                  </div>
                  <div className="col-md-7 d-flex justify-content-end align-items-center">
                    <SearchBar
                      placeholder="Search Apps..."
                      buttonLabel="Q"
                      onChange={(e) => setSearch(e.target.value)}
                      width="250px"
                      className="custom-search-bar"
                      inputClassName="custom-input"
                      buttonClassName="custom-button"
                    />
                    <button className="ms-3 entra-button" type="submit">
                      Visible Columns
                    </button>
                    <button className="icon-btn ms-3">
                      <FilterIcon height={20} width={20} />
                    </button>
                  </div>
                </div>
              </div>
              <div className="container p-4">
                <div className="table-container">
                  <div className="table-header fixed">
                    <table className="table table-fixed">
                      <thead>
                        <tr>
                          <th style={{ width: "19%" }}>
                            Request for
                            <button
                              className="tab-down-btn"
                              onClick={handleSort}
                            >
                              <DownArrowIcon />
                            </button>
                          </th>
                          <th style={{ width: "19%" }}>App Name</th>
                          <th style={{ width: "20%" }}>Approver</th>
                          <th style={{ width: "19%" }}>Date</th>
                          <th>Decision</th>
                        </tr>
                      </thead>
                    </table>
                    <div className="divider"></div>
                  </div>
                  <div className="table-body">
                    <table className="table table-fixed">
                      <tbody>
                        {currentRows.map((row, index) => (
                          <tr key={index}>
                            <td>{row.requestFor}</td>
                            <td>{row.appName}</td>
                            <td>{row.approver}</td>
                            <td>{row.date}</td>
                            <td>
                              <button
                                className={`table-btn-${row.decision.toLowerCase()}`}
                              >
                                {row.decision}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                <div className="pt-4">
                  {filteredData.length > 0 && (
                    <Pagination
                      currentPage={currentPage}
                      totalPages={totalPages}
                      onPageChange={handlePageChange}
                      rowsPerPage={rowsPerPage}
                      onRowsPerPageChange={handleRowsPerPageChange}
                    />
                  )}
                </div>
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </>
  );
};

export default RequestHistoryApp;
