import React,{useState} from 'react'
import SideNav from '../SelfServiceSideNav'
import { ReactComponent as FilterIcon } from "../../../assets/icons/filter.svg";
import { ReactComponent as MyGroupIcon  } from "../../../assets/icons/MyGroupIcon.svg";
import { ReactComponent as DownArrowIcon } from "../../../assets/icons/down_arrow.svg";
import Pagination from "../../../utils/Pagination";
import SearchBar from '../../../components/Shared/SearchBar';
import Footer from '../../../components/Footer';

const GroupHistory = () => {
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const data = [
    { requestFor: "Akansha Gill", groupName: "International Marketers", approver: "Anisha Giri", date: "11/02/24", decision: "Approved" },
    { requestFor: "Alaysa Volko", groupName: "Oracle order", approver: "Anisha Giri", date: "19/04/24", decision: "denied" },
    { requestFor: "Alice Adams", groupName: "Sales Sorcers", approver: "Jaya Singh", date: "28/11/24", decision: "Approved" },
    { requestFor: "Rani Patel", groupName: "Project Management", approver: "Xiao Wangh", date: "05/07/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorcers", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Tao Xu", groupName: "International Marketers", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorcerers", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Grace Brown", groupName: "Project Management", approver: "xiao Wangh", date: "19/0424", decision: "Denied" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "10/03/94", decision: "Approved" },
    { requestFor: "Rani Patel", groupName: "oracle order", approver: "Renu Singh", date: "15/08/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Alaysa Volko", groupName: "Project Management", approver: "abc", date: "19/04/24", decision: "denied" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "28/11/24", decision: "Approved" },
    { requestFor: "Rani Patel", groupName: "Figma", approver: "Renu Singh", date: "05/07/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Tao Xu", groupName: "oracle order", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Grace Brown", groupName: "Project Management", approver: "abc", date: "19/0424", decision: "Denied" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "10/03/94", decision: "Approved" },
    { requestFor: "Rani Patel", groupName: "oracle order", approver: "Renu Singh", date: "15/08/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
     { requestFor: "Akansha Gill", groupName: "International Marketers", approver: "Anisha Giri", date: "11/02/24", decision: "Approved" },
    { requestFor: "Alaysa Volko", groupName: "Oracle order", approver: "Anisha Giri", date: "19/04/24", decision: "denied" },
    { requestFor: "Alice Adams", groupName: "Sales Sorcers", approver: "Jaya Singh", date: "28/11/24", decision: "Approved" },
    { requestFor: "Rani Patel", groupName: "Project Management", approver: "Xiao Wangh", date: "05/07/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorcers", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Tao Xu", groupName: "International Marketers", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorcerers", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Grace Brown", groupName: "Project Management", approver: "xiao Wangh", date: "19/0424", decision: "Denied" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "10/03/94", decision: "Approved" },
    { requestFor: "Rani Patel", groupName: "oracle order", approver: "Renu Singh", date: "15/08/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Alaysa Volko", groupName: "Project Management", approver: "abc", date: "19/04/24", decision: "denied" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "28/11/24", decision: "Approved" },
    { requestFor: "Rani Patel", groupName: "Figma", approver: "Renu Singh", date: "05/07/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Tao Xu", groupName: "oracle order", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" },
    { requestFor: "Grace Brown", groupName: "Project Management", approver: "abc", date: "19/0424", decision: "Denied" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "10/03/94", decision: "Approved" },
    { requestFor: "Rani Patel", groupName: "oracle order", approver: "Renu Singh", date: "15/08/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "05/03/24", decision: "Approved" },
    { requestFor: "Alice Adams", groupName: "Sales Sorceres", approver: "Jaya Singh", date: "11/02/24", decision: "Approved" }
   
  ];

  const totalPages = Math.ceil(data.length / rowsPerPage);

  const handleSearch = () => {};



  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    setSelectAll(false);
    setSelectedRows([]);
  };
  const handleRowsPerPageChange = (rows) => {
    setRowsPerPage(rows);
    setCurrentPage(1); // Reset to first page when rows per page change
  };

  const currentRows = data.length > rowsPerPage 
    ? data.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage)
    : data;
    

  return (
    <>
   <div className="container-fluid m-0">
        <div className="row">
          <div className="col-md-2 sidebar">
            <SideNav />
          </div>
          <div className="col-md-10 main-container">
            <div className="border top-left-border bg-white mb-10">
              <div className="page-header fixed">
                <div className="row align-items-center pt-3">
                  <div className="col-md-5">
                    <h1 className="mb-0 page-heading">
                      <span className="me-3">
                        <MyGroupIcon height={48} width={48} />
                      </span>
                      Request History for Groups
                    </h1>
                  </div>
                  <div className="col-md-7 d-flex justify-content-end align-items-center">
                    <SearchBar
                      placeholder="Search Apps..."
                      buttonLabel="Q"
                      onSearch={handleSearch}
                      width="250px"
                      className="custom-search-bar"
                      inputClassName="custom-input"
                      buttonClassName="custom-button"
                    />
                     <button
                        className="ms-3 entra-button"
                        type="submit"
                      >
                        Visible Columns
                      </button>
                    <button className="icon-btn ms-3">
                      <FilterIcon height={20} width={20} />
                    </button>
                  </div>
                </div>
              </div>
              <div className="container p-4">
                <div className="table-container">
                  <div className="table-header fixed">
                    <table className="table table-fixed">
                      <thead>
                        <tr>
                          
                          <th>Requested for
                            <button className="tab-down-btn"><DownArrowIcon height={16} width={16} /></button>
                          </th>
                          <th>Group Name</th>
                          <th>Approver</th>
                          <th>Date</th>
                          <th>Decision</th>
                        </tr>
                      </thead>
                    </table>
                    <div className="divider"></div>
                  </div>
                  <div className="table-body">
                    <table className="table table-fixed">
                      <tbody>
                        {currentRows.map((row, index) => (
                          <tr key={index}>
                          
                            <td>{row.requestFor}</td>
                            <td>{row.groupName}</td>
                            <td>{row.approver}</td>
                            <td>{row.date}</td>
                            <td>
                              <button className={`table-btn-${row.decision.toLowerCase()}`}>
                                {row.decision}
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  
                  </div>
                </div>
                <div className="pt-4">
                {data.length > 0 && (
                  <Pagination
                    currentPage={currentPage}
                    totalPages={totalPages}
                    onPageChange={handlePageChange}
                    onRowsPerPageChange={handleRowsPerPageChange}
                  />
                )}
                </div>
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </>
  )
}

export default GroupHistory