import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import SideNav from "../SelfServiceSideNav";
import Footer from "../../../components/Footer";
import SearchBar from "../../../components/Shared/SearchBar";
import Pagination from "../../../utils/Pagination";

import { ReactComponent as DownArrowIcon } from "../../../assets/icons/down_arrow.svg";
import { ReactComponent as FilterIcon } from "../../../assets/icons/filter.svg";

//import { ReactComponent as adminIcon } from "../../../assets/icons/admin.svg";


const ManageGroup = () => {
  const [isEditable, setIsEditable] = useState(false);
  const [selectedRows, setSelectedRows] = useState([]);
  const [selectAll, setSelectAll] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortOrder, setSortOrder] = useState("asc");
  const rowsPerPage = 10;
  const navigate = useNavigate();
  const location = useLocation();
  const group = location.state?.group;

  if (!group) {
    navigate('/self-service/my-groups/view-all');
    return null; // or some loading/error state
  }


  const handleGoBack = () => {
    navigate('/self-service/my-groups/view-all');
  };
  const dataValue = group.members || []; 
  const data = [
    {
      id: 1,
      name: "Anisha Giri",
      email: "anishagiri@inspiritvision.com",
      role: "Owner",
      decision: ["Remove Ownership", "Remove"],
    },
    {
      id: 2,
      name: "Jane Doe",
      email: "JaneDoe@inspiritvision.com",
      role: "Owner",
      decision: ["Remove Ownership", "Remove"],
    },
    {
      id: 3,
      name: "Barkha Desai",
      email: "barkha.d@inspiritvision.com",
      role: "Member",
      decision: ["Make Owner", "Remove"],
    },
    {
      id: 4,
      name: "Biyu Huang",
      email: "biyu@inspiritvision.com",
      role: "Member",
      decision: ["Make Owner", "Remove"],
    },
    {
      id: 5,
      name: "Grace Brown",
      email: "grace@inspiritvision.com",
      role: "Member",
      decision: ["Make Owner", "Remove"],
    },
    {
      id: 6,
      name: "Harsha Gupta",
      email: "iharshaguptainspiritvision.com",
      role: "Member",
      decision: ["Make Owner", "Remove"],
    },
    {
      id: 7,
      name: "May Carters",
      email: "may.c@inspiritvision.com",
      role: "Member",
      decision: ["Make Owner", "Remove"],      
    }
  ];

  const handleEditClick = () => {
    setIsEditable(!isEditable);
  };

  const handleLeaveClick = () => {
    if (window.confirm("Are you sure you want to leave?")) {
      console.log("User confirmed to leave");
    } else {
      console.log("User canceled the leave action");
    }
  };

  const handleDeleteClick = () => {
    if (window.confirm("Are you sure you want to Delete Group?")) {
      console.log("yes");
    } else {
      console.log("No");
    }
  };

  const handleSearch = () => {};

  const handleSelectAll = (e) => {
    const isChecked = e.target.checked;
    setSelectAll(isChecked);
    if (isChecked) {
      const allRowIds = currentRows.map((row) => row.id);
      setSelectedRows(allRowIds);
    } else {
      setSelectedRows([]);
    }
  };

  const handleRowSelect = (id) => {
    setSelectedRows((prevSelectedRows) => {
      if (prevSelectedRows.includes(id)) {
        return prevSelectedRows.filter((rowId) => rowId !== id);
      } else {
        return [...prevSelectedRows, id];
      }
    });
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    setSelectAll(false);
    setSelectedRows([]);
  };
  const sortData = () => {
    const sorted = [...data].sort((a, b) => {
      const comparison = a.name.localeCompare(b.name);
      return sortOrder === "asc" ? comparison : -comparison;
    });
    return sorted;
  };

  const handleSort = () => {
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };

  const sortedData = sortData();

  const currentRows =
    sortedData.length > rowsPerPage
      ? sortedData.slice(
          (currentPage - 1) * rowsPerPage,
          currentPage * rowsPerPage
        )
      : sortedData;

  const totalPages = Math.ceil(data.length / rowsPerPage);


  return (
    <>
      <div className="container-fluid m-0">
        <div className="row">
          <div className="col-md-2 sidebar">
            <SideNav />
          </div>
          <div className="col-md-10 main-container">
            <div className="border top-left-border bg-white mb-10">
              <div className="page-header fixed">
                <button className="btn-transp ms-3" onClick={handleGoBack}> &#10094; Go Back</button>
                <div className="row align-items-center pt-3">
                  <div className="col-md-5">
                    <h1 className="mb-0 page-heading">
                      <span className="me-3"></span>
                      {group.groupName}
                    </h1>
                  </div>
                  <div className="col-md-7 d-flex justify-content-end align-items-center">
                    <button
                      className="ms-3 entra-button"
                      type="button"
                      onClick={handleEditClick}
                    >
                      {isEditable ? "Save" : "Edit"}
                    </button>
                    <button 
                      className="ms-3 entra-button" 
                      type="submit"
                      onClick={handleLeaveClick}>
                      Leave
                    </button>
                    <button 
                      className="ms-3 entra-button" 
                      type="submit"
                      onClick={handleDeleteClick}>
                      Delete
                    </button>
                  </div>
                </div>
              </div>
              <div className="container p-4">
                <div className="form-container">
                  <form>
                    <div className="row">
                      <div className="col-md-6">
                        <div className="row mb-3">
                          <label
                            htmlFor="groupType"
                            className="col-sm-4 col-form-label"
                          >
                            Group Type
                          </label>
                          <div className="col-sm-6">
                            <input
                              type="text"
                              className="form-control"
                              id="groupType"
                              placeholder={`${group.type}`}
                              readOnly={!isEditable}
                            />
                          </div>
                        </div>
                        <div className="row mb-3">
                          <label
                            htmlFor="membershipType"
                            className="col-sm-4 col-form-label"
                          >
                            Membership Type
                          </label>
                          <div className="col-sm-6">
                            <input
                              type="text"
                              className="form-control"
                              id="membershipType"
                              placeholder="Assigned"
                              readOnly={!isEditable}
                            />
                          </div>
                        </div>
                      </div>
                      <div className="col-md-6">
                        <div className="row mb-3">
                          <label
                            htmlFor="description"
                            className="col-sm-2 col-form-label"
                          >
                            Description
                          </label>
                          <div className="col-sm-10">
                            <textarea
                              className="form-control"
                              id="description"
                              placeholder={`${group.describe}`}
                              readOnly={!isEditable}
                            ></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>

                <div className="row mt-4">
                  <div className="col-md-4">
                    <div className="bg-flex me-4">
                      <span>Members </span>
                      <span className="count-bg">7</span>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="bg-flex me-4">
                      <span>Owners </span>
                      <span className="count-bg">2</span>
                    </div>
                  </div>
                  <div className="col-md-4">
                    <div className="bg-flex">
                      <span>Policy </span>
                      <span className="description">Owner approval required.</span>
                    </div>
                  </div>
                </div>
                <div className="table-area">
                  <div className="row align-items-center pt-3">
                    <div className="col-md-5">
                      <h1 className="mb-0 page-heading">
                        <span className="me-3"></span>
                        Members
                      </h1>
                    </div>
                    <div className="col-md-7 d-flex justify-content-end align-items-center">
                      <SearchBar
                        placeholder="Search..."
                        buttonLabel="Q"
                        onSearch={handleSearch}
                        width="250px"
                        className="custom-search-bar"
                        inputClassName="custom-input"
                        buttonClassName="custom-button"
                      />
                      <button className="ms-3 entra-button" type="submit">
                        Add Members
                      </button>
                      <button className="icon-btn ms-3">
                        <FilterIcon height={20} width={20} />
                      </button>
                    </div>
                  </div>
                  <div className="containerr">
                    <table className="table mt-4">
                      <thead className="divider">
                        <tr>
                          <th scope="col">
                            <input
                              className="input all-check"
                              type="checkbox"
                              checked={selectAll}
                              onChange={handleSelectAll}
                            />
                          </th>
                          <th scope="col">Name 
                            <button 
                              className="tab-down-btn ps-1"
                              onClick={handleSort}>
                              <DownArrowIcon />
                            </button>
                          </th>
                          <th scope="col">Email</th>
                          <th scope="col">Role</th>
                          <th scope="col">Actions</th>
                        </tr>
                      </thead>
               
                      <tbody>
                        {currentRows.map((row) => (
                          <tr key={row.id}>
                            <td>
                              <input
                                className="input single-check"
                                type="checkbox"
                                checked={selectedRows.includes(row.id)}
                                onChange={() => handleRowSelect(row.id)}
                              />
                            </td>
                            <td>{row.name}</td>
                            <td>{row.email}</td>
                            <td>{row.role}</td>
                            <td style={{textAlign:"right"}}>
                              {row.decision.map((action, index) => (
                                <button key={index} className="ms-1 entra-button">
                                  {action}
                                </button>
                              ))}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                    <div className="pt-4">
                      {data.length > 0 && (
                        <Pagination
                          currentPage={currentPage}
                          totalPages={totalPages}
                          onPageChange={handlePageChange}
                        />
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </>
  );
};

export default ManageGroup;
