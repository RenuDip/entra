import React, { useState } from "react";
import { useSelector } from "react-redux";
import SideNav from "../SelfServiceSideNav";
import Footer from "../../../components/Footer";
import SearchBar from "../../../components/Shared/SearchBar";
import { ReactComponent as FilterIcon } from "../../../assets/icons/filter.svg";
import { ReactComponent as DownArrowIcon } from "../../../assets/icons/down_arrow.svg";
import { ReactComponent as MyGroupIcon } from "../../../assets/icons/MyGroupIcon.svg";
import Pagination from "../../../utils/Pagination";
import RequestModal from  "../../../components/Shared/RequestModal"

const RequestGroup = () => {
  const [selectedOptions, setSelectedOptions] = useState([]);
  const [requiredForPeriod, setRequiredForPeriod] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [formState, setFormState] = useState({});
  const [buttonText, setButtonText] = useState({});
  const [showMessage, setShowMessage] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [rowsPerPage, setRowsPerPage] = useState(10);

  const [sortOrder, setSortOrder] = useState("asc");

  const data = useSelector((state) => state.requestGroup.value);

  const options = [
    { value: "name1", label: "Name 1" },
    { value: "name2", label: "Name 2" },
    { value: "name3", label: "Name 3" },
    { value: "name4", label: "Name 4" },
    { value: "name5", label: "Name 5" },
    { value: "name6", label: "Name 6" },
  ];

  const totalPages = Math.ceil(data.length / rowsPerPage);

  const handleSearch = () => {};
  const handleSelectChange = (selected) => {
    setSelectedOptions(selected);
  };

  const handleToggle = () => {
    setRequiredForPeriod(!requiredForPeriod);
  };

  const handleJustificationChange = (index, event) => {
    setFormState((prevState) => ({
      ...prevState,
      [index]: {
        ...prevState[index],
        businessJustification: event.target.value,
      },
    }));
  };

  const handleSubmit = (index) => {
    const formData = formState[index];
    if (!formData || !formData.businessJustification) {
      setErrorMessage("Business Justification is required.");
      return;
    }
    console.log("Form Data Submitted:", formData);
    setButtonText((prevState) => ({
      ...prevState,
      [index]: "Requested",
    }));
    setShowMessage(true);
    setErrorMessage("");
    setTimeout(() => setShowMessage(false), 3000);
    document.querySelector(`#modal${index} .btn-close`).click();
  };

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const sortData = () => {
    const sorted = [...data].sort((a, b) => {
      const comparison = a.requestFor.localeCompare(b.requestFor);
      return sortOrder === "asc" ? comparison : -comparison;
    });
    return sorted;
  };

  const handleSort = () => {
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };

  const sortedData = sortData();
  const handleRowsPerPageChange = (rows) => {
    setRowsPerPage(rows);
    setCurrentPage(1); // Reset to first page when rows per page change
  };

  const currentRows =
    sortedData.length > rowsPerPage
      ? sortedData.slice(
          (currentPage - 1) * rowsPerPage,
          currentPage * rowsPerPage
        )
      : sortedData;

  return (
    <>
      <div className="container-fluid m-0">
        <div className="row">
          <div className="col-md-2 sidebar">
            <SideNav />
          </div>
          <div className="col-md-10 main-container">
            <div className="border top-left-border bg-white mb-10">
              <div className="page-header fixed">
                <div className="row align-items-center pt-3">
                  <div className="col-md-5">
                    <h1 className="mb-0 page-heading">
                      <span className="me-3">
                        <MyGroupIcon height={48} width={48} />
                      </span>
                      Request Groups
                    </h1>
                  </div>
                  <div className="col-md-7 d-flex justify-content-end align-items-center">
                    <SearchBar
                      placeholder="Search Group..."
                      buttonLabel="Q"
                      onSearch={handleSearch}
                      width="250px"
                      className="custom-search-bar"
                      inputClassName="custom-input"
                      buttonClassName="custom-button"
                    />
                    <button className="icon-btn ms-2">
                      <FilterIcon height={18} width={18} />
                    </button>
                  </div>
                </div>
              </div>
              <div className="container p-4">
                <div className="table-container">
                  <div className="table-header fixed">
                    <table className="table table-fixed">
                      <thead>
                        <tr>
                          <th style={{ width: "28%" }}>
                            Name{" "}
                            <button
                              className="tab-down-btn ps-1"
                              onClick={handleSort}
                            >
                              <DownArrowIcon />
                            </button>
                          </th>
                          <th style={{ width: "41%" }}>Description</th>
                          <th style={{ width: "15%" }}>Type</th>
                          <th></th>
                        </tr>
                      </thead>
                    </table>
                    <div className="divider"></div>
                  </div>
                  <div className="table-body">
                    <table className="table table-fixed">
                      <tbody>
                        {currentRows.map((row, index) => (
                          <tr key={index}>
                            <td style={{ width: "28%" }} className="h5">
                              {row.requestFor}
                            </td>
                            <td style={{ width: "45%" }}>{row.appName}</td>
                            <td style={{ width: "15%" }}>M365</td>
                            <td>
                              <button
                                className="entra-button"
                                data-bs-toggle={
                                  buttonText[index] !== "Requested"
                                    ? "modal"
                                    : ""
                                }
                                data-bs-target={`#modal${index}`}
                              >
                                {buttonText[index] || "Request"}
                              </button>
                              {buttonText[index] !== "Requested" && (
                                <RequestModal
                                  index={index}
                                  row={row}
                                  requiredForPeriod={requiredForPeriod}
                                  handleToggle={handleToggle}
                                  selectedOptions={selectedOptions}
                                  handleSelectChange={handleSelectChange}
                                  formState={formState}
                                  handleJustificationChange={
                                    handleJustificationChange
                                  }
                                  handleSubmit={handleSubmit}
                                  options={options}
                                />
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
                {showMessage && (
                  <div className="alert alert-success" role="alert">
                    Your request has been submitted.
                  </div>
                )}
                {errorMessage && (
                  <div className="alert alert-danger" role="alert">
                    {errorMessage}
                  </div>
                )}
                <div className="pt-4">
                  {data.length > 0 && (
                    <Pagination
                      currentPage={currentPage}
                      totalPages={totalPages}
                      onPageChange={handlePageChange}
                      onRowsPerPageChange={handleRowsPerPageChange}

                    />
                  )}
                </div>
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </>
  );
};

export default RequestGroup;
