import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import Footer from "../../../components/Footer";
import SideNav from "../SelfServiceSideNav";
import { ReactComponent as FilterIcon } from "../../../assets/icons/filter.svg";
import { useSelector } from "react-redux";
import SearchBar from "../../../components/Shared/SearchBar";
import Pagination from "../../../utils/Pagination";
import { ReactComponent as MyGroupIcon } from "../../../assets/icons/MyGroupIcon.svg";
import { ReactComponent as DownArrowIcon } from "../../../assets/icons/down_arrow.svg";
import { useMsal } from "@azure/msal-react";
import axios from "axios";
import configData from "../../../config.json";

const ViewGroup = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [sortOrder, setSortOrder] = useState("asc");
  const [data, setData] = useState([]);
  const [search, setSearch] = useState("");
  const { instance, accounts } = useMsal();
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const navigate = useNavigate();
  const fetchApi = async () => {
    try {
      const tokenResponse = await instance.acquireTokenSilent({
        scopes: ["User.Read"],
        account: accounts[0],
      });
  
      const response = await axios.get(`${configData.ENVISION_BASE_URL}/json/allGroups`, {
        headers: {
          'Authorization': 'Bearer ' + tokenResponse.accessToken
        }
      });
  
      // Safely access response data
     
      const ownedGroups = response.data.ownedGroups?.value || [];
      const memberOfGroups = response.data.memberOfGroups?.value || [];
  
      // Combine and process the groups
      const combinedGroups = [...ownedGroups, ...memberOfGroups];
  
      setData(combinedGroups);
      console.log(response.data, "Data fetched successfully");
    } catch (error) {
      console.error('Error fetching data:', error.response ? error.response.data : error.message);
    }
  };
  

  useEffect(() => {
    fetchApi();
  },[]);

  const handleGroupSelect = (group) => {
    navigate("/self-service/my-groups/manage-group", { state: { group } });
  };

  //const data = useSelector((state) => state.groupView.value);
  const totalPages = Math.ceil(data.length / rowsPerPage);



  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const sortData = () => {
    const sorted = [...data].sort((a, b) => {
      const comparison = a.displayName.localeCompare(b.displayName);
      return sortOrder === "asc" ? comparison : -comparison;
    });
    return sorted;
  };

  const handleSort = () => {
    setSortOrder(sortOrder === "asc" ? "desc" : "asc");
  };
  

  const sortedData = sortData();
  const filteredData = sortedData.filter((row) => {
    const cleanedSearch = search.replace(/\s+/g, "").trim().toLowerCase();  // Remove spaces from search input
    const cleanedAppName = row.displayName.replace(/\s+/g, "").trim().toLowerCase();  // Remove spaces from app name
    return cleanedAppName.includes(cleanedSearch);  // Use cleaned variables for comparison
  });
  const currentRows =
  filteredData.length > rowsPerPage
      ? filteredData.slice(
          (currentPage - 1) * rowsPerPage,
          currentPage * rowsPerPage
        )
      : filteredData;
  
    

  const hasNoRecords = filteredData.length === 0;
  const handleRowsPerPageChange = (rows) => {
    setRowsPerPage(rows);
    setCurrentPage(1); // Reset to first page when rows per page change
  };
  return (
    <>
      <div className="container-fluid m-0">
        <div className="row">
          <div className="col-md-2 sidebar">
            <SideNav />
          </div>
          <div className="col-md-10 main-container">
            <div className="border top-left-border bg-white mb-10">
              <div className="page-header fixed">
                <div className="row align-items-center pt-3">
                  <div className="col-md-5">
                    <h1 className="mb-0 page-heading">
                      <span className="me-3">
                        <MyGroupIcon height={40} width={48} />
                      </span>
                      My Groups
                    </h1>
                  </div>
                  <div className="col-md-7 d-flex justify-content-end align-items-center">
                    <SearchBar
                      placeholder="Search Group..."
                      buttonLabel="Q"
                      onChange={setSearch}
                      width="250px"
                      className="custom-search-bar"
                      inputClassName="custom-input"
                      buttonClassName="custom-button"
                    />
                    <button className="ms-3 entra-button" type="submit">
                      Visible Columns
                    </button>
                    <button className="icon-btn ms-3">
                      <FilterIcon height={20} width={20} />
                    </button>
                  </div>
                </div>

                <ul
                  className="nav nav-pills mb-3 ms-3 mt-3"
                  id="pills-tab"
                  role="tablist"
                  style={{ width: "22.2%", height :"40px" }}
                >
                  <li className="nav-item" role="presentation">
                    <button
                      className="nav-link active btn-pills"
                      id="pills-home-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#pills-home"
                      type="button"
                      role="tab"
                      aria-controls="pills-home"
                      aria-selected="true"
                    >
                      Active
                    </button>
                  </li>
                  <li className="nav-item" role="presentation">
                    <button
                      className="nav-link btn-pills"
                      id="pills-profile-tab"
                      data-bs-toggle="pill"
                      data-bs-target="#pills-profile"
                      type="button"
                      role="tab"
                      aria-controls="pills-profile"
                      aria-selected="false"
                    >
                      Requested
                      <span className="count">0</span>
                    </button>
                  </li>
               
                </ul>
              </div>
              <div className="tab-content" id="pills-tabContent">
                <div
                  className="tab-pane fade show active"
                  id="pills-home"
                  role="tabpanel"
                  aria-labelledby="pills-home-tab"
                >
                  <div className="container p-4">
                    <div className="table-container mb-4">
                      <div className="table-header fixed tabs-table-head">
                        <table className="table table-fixed">
                          <thead>
                            <tr>
                              <th style={{ width: "19%" }}>
                                Name
                                <button className="tab-down-btn">
                                  <DownArrowIcon onClick={handleSort} />
                                </button>
                              </th>
                              <th style={{ width: "38%" }}>Description</th>
                              <th style={{ width: "17%" }}>Type</th>
                              <th>Role</th>
                              <th></th>
                            </tr>
                          </thead>
                        </table>
                        <div className="divider"></div>
                      </div>
                      <div className="table-body tabs-table-body">
                        <table className="table table-fixed">
                        <tbody>
  {hasNoRecords ? (
    <tr>
      <td colSpan={5} className="text-center">
        No records found
      </td>
    </tr>
  ) : (
    currentRows.map((row, index) => (
      <tr key={index} className="p-2">
        <td className="h5" style={{ width: "20%" }}>
          {row.displayName}
        </td>
        <td style={{ width: "40%" }}>{row.description}</td>
        <td style={{ width: "18%" }}>{row.groupTypes}</td>
        <td>{row.role}</td>
        <td className="text-center">
          <button
            className="btn-transp"
            onClick={() => handleGroupSelect(row)}
          >
            {" "}
            &#10095;
          </button>
        </td>
      </tr>
    ))
  )}
</tbody>

                        </table>
                      </div>
                    </div>
                    <div className="pt-4">
                      {data.length > 0 && (
                        <Pagination
                          currentPage={currentPage}
                          totalPages={totalPages}
                          onPageChange={handlePageChange}
                          onRowsPerPageChange={handleRowsPerPageChange}
                        />
                      )}
                    </div>
                  </div>
                </div>
                <div
                  className="tab-pane fade"
                  id="pills-profile"
                  role="tabpanel"
                  aria-labelledby="pills-profile-tab"
                >
                 <div className="container p-4">
                    <div className="table-container mb-4">
                      <div className="table-header fixed tabs-table-head">
                        <table className="table table-fixed">
                          <thead>
                            <tr>
                              <th style={{ width: "19%" }}>
                                Name
                                <button className="tab-down-btn" onClick={handleSort}>
                                  <DownArrowIcon />
                                </button>
                              </th>
                              <th style={{ width: "38%" }}>Description</th>
                              <th style={{ width: "17%" }}>Type</th>
                              <th>Role</th>
                              <th></th>
                            </tr>
                          </thead>
                        </table>
                        <div className="divider"></div>
                      </div>
                      <div className="table-body tabs-table-body">
                        <table className="table table-fixed">
                          <tbody>
                            {/* {currentRows.slice(0, 3).map((row, index) => (
                              <tr key={index} className="p-2">
                                <td className="h5" style={{ width: "20%" }}>
                                  {row.groupName}
                                </td>
                                <td style={{ width: "40%" }}>{row.describe}</td>
                                <td style={{ width: "18%" }}>{row.type}</td>
                                <td>{row.role}</td>
                                <td className="text-center">
                                  <button
                                    className="btn-transp"
                                    onClick={() => handleGroupSelect(row)}
                                  >
                                    {" "}
                                    &#10095;
                                  </button>
                                </td>
                              </tr>
                            ))} */}
                            <td colSpan={4} >No data  Available</td>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div className="pt-4">
                      {data.length > rowsPerPage && (
                        <Pagination
                          currentPage={currentPage}
                          totalPages={totalPages}
                          onPageChange={handlePageChange}
                        />
                      )}
                    </div>
                  </div>
                </div>
              
              </div>
            </div>
            <Footer />
          </div>
        </div>
      </div>
    </>
  );
};

export default ViewGroup;
