import { NavLink, Link } from "react-router-dom";
import { ReactComponent as HomeIcon } from "./../../assets/icons/access.svg";
import { ReactComponent as MyAppIcon } from "./../../assets/icons/myApps.svg";
import { ReactComponent as MyGroupIcon } from "./../../assets/icons/MyGroupIcon.svg";

const SideNav = () => {
  return (
    <div className="SideNav">
      <nav>
        <div className="row">
          <h4 className="side_nav-title">Self-Service</h4>
          <hr className="custom-hr" />
          <div>
            <div>
              <span className="sideIcon me-3">
                <MyAppIcon height={32} width={32} />
              </span>

              <NavLink className="non-nav-link main-link" end>
                My Apps
              </NavLink>
            </div>
          </div>

          <NavLink
            className="nav-link sideNav-link mt-1"
            to="/self-service/my-apps/my-view"
          >
            View All
          </NavLink>
          {/* <NavLink
            className="nav-link sideNav-link"
            to="/self-service/my-apps/request-new"
          >
            Request New
          </NavLink>
          <NavLink
            className="nav-link sideNav-link"
            to="/self-service/my-apps/request-history"
          >
            Request History
          </NavLink> */}
        </div>
        <div className="row">
          <div>
            {" "}
            <span className="sideIcon me-3">
              <HomeIcon height={32} width={32} />
            </span>
            <NavLink className="non-nav-link main-link" end>
              My Access Packages
            </NavLink>
          </div>

          <NavLink
            className="nav-link sideNav-link mt-1"
            to="/self-service/my-access-packages/view"
          >
            View All
          </NavLink>

          {/* <NavLink
            className="nav-link sideNav-link"
            to="/self-service/my-access-packages/request-app"
          >
            Request New
          </NavLink> */}
          <NavLink
            className="nav-link sideNav-link"
            to="/self-service/my-access-packages/request-history"
          >
            Request History
          </NavLink>
        </div>
        <div className="row">
          <div>
            {" "}
            <span className="sideIcon me-3">
              <MyGroupIcon height={32} width={32} />
            </span>
            <NavLink className="non-nav-link main-link" end>
              My Groups
            </NavLink>
          </div>
          <NavLink
            className="nav-link sideNav-link mt-1"
            to="/self-service/my-groups/view-all"
          >
            View All
          </NavLink>
          {/* <NavLink
            className="nav-link sideNav-link"
            to="/self-service/my-groups/request-new"
          >
            Request New
          </NavLink>
          <NavLink
            className="nav-link sideNav-link"
            to="/self-service/my-groups/request-history"
          >
            Request History
          </NavLink> */}
        </div>
      </nav>
    </div>
  );
};

export default SideNav;
