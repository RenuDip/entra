import React, { useEffect, useState } from 'react';

const ZoomDetection = ({ children }) => {
  const [isResized, setIsResized] = useState(false);

  const detectWindowSize = () => {
    const { innerWidth } = window;
    setIsResized(innerWidth !== 1366);
  };

  useEffect(() => {
    detectWindowSize();
    window.addEventListener('resize', detectWindowSize);

    return () => {
      window.removeEventListener('resize', detectWindowSize);
    };
  }, []);

  return (
    <div className={isResized ? 'blurred-container' : ''}>
      {isResized && (
        <div className="resize-warning">
          Please resize the window to 1366px width.
        </div>
      )}
      {children}
    </div>
  );
};

export default ZoomDetection;