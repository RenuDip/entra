import React from 'react';

const Pagination = ({ currentPage, totalPages, onPageChange, rowsPerPage = 10, onRowsPerPageChange }) => {

  const handlePrevious = () => {
    if (currentPage > 1) {
      onPageChange(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages) {
      onPageChange(currentPage + 1);
    }
  };

  const handlePageNumberClick = (pageNumber) => {
    onPageChange(pageNumber);
  };

  const handleRowsPerPageChange = (event) => {
    onRowsPerPageChange(Number(event.target.value));
  };

  const renderPageNumbers = () => {
    const pageNumbers = [];
    const maxPageNumbersToShow = 4;

    if (totalPages <= maxPageNumbersToShow) {
      for (let i = 1; i <= totalPages; i++) {
        pageNumbers.push(
          <button
            key={i}
            className={`page-number ${currentPage === i ? 'active' : ''}`}
            onClick={() => handlePageNumberClick(i)}
          >
            {i}
          </button>
        );
      }
    } else {
      if (currentPage <= 3) {
        for (let i = 1; i <= maxPageNumbersToShow - 1; i++) {
          pageNumbers.push(
            <button
              key={i}
              className={`page-number ${currentPage === i ? 'active' : ''}`}
              onClick={() => handlePageNumberClick(i)}
            >
              {i}
            </button>
          );
        }
        pageNumbers.push(<span key="ellipsis-end">...</span>);
        pageNumbers.push(
          <button
            key={totalPages}
            className={`page-number ${currentPage === totalPages ? 'active' : ''}`}
            onClick={() => handlePageNumberClick(totalPages)}
          >
            {totalPages}
          </button>
        );
      } else if (currentPage > 3 && currentPage < totalPages - 2) {
        pageNumbers.push(
          <button
            key={1}
            className="page-number"
            onClick={() => handlePageNumberClick(1)}
          >
            1
          </button>
        );
        pageNumbers.push(<span key="ellipsis-start">...</span>);
        for (let i = currentPage - 1; i <= currentPage + 1; i++) {
          pageNumbers.push(
            <button
              key={i}
              className={`page-number ${currentPage === i ? 'active' : ''}`}
              onClick={() => handlePageNumberClick(i)}
            >
              {i}
            </button>
          );
        }
        pageNumbers.push(<span key="ellipsis-end">...</span>);
        pageNumbers.push(
          <button
            key={totalPages}
            className={`page-number ${currentPage === totalPages ? 'active' : ''}`}
            onClick={() => handlePageNumberClick(totalPages)}
          >
            {totalPages}
          </button>
        );
      } else {
        pageNumbers.push(
          <button
            key={1}
            className="page-number"
            onClick={() => handlePageNumberClick(1)}
          >
            1
          </button>
        );
        pageNumbers.push(<span key="ellipsis-start">...</span>);
        for (let i = totalPages - (maxPageNumbersToShow - 2); i <= totalPages; i++) {
          pageNumbers.push(
            <button
              key={i}
              className={`page-number ${currentPage === i ? 'active' : ''}`}
              onClick={() => handlePageNumberClick(i)}
            >
              {i}
            </button>
          );
        }
      }
    }
    return pageNumbers;
  };

  return (
    <div className="row ps-4 d-flex">
      <div className="col-md-2">
        <label className="page filter">
          Show per page :
          <select value={rowsPerPage} onChange={handleRowsPerPageChange} className="paginate-select">
            <option value={5}>5</option>
            <option value={10}>10</option>
            <option value={20}>20</option>
            <option value={50}>50</option>
          </select>
        </label>
      </div>
      <div className="col-md-8 text-center">
        <div className="pagination">
          <button onClick={handlePrevious} disabled={currentPage === 1}>
            &#10094;
          </button>
          {renderPageNumbers()}
          <button onClick={handleNext} disabled={currentPage === totalPages}>
            &#10095;
          </button>
        </div>
      </div>
    </div>
  );
};

export default Pagination;
