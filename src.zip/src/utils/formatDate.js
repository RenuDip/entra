
export const formatDate = (dateTimeString) => {
    const date = new Date(dateTimeString);
    return date.toISOString().slice(0, 10); // Gets the YYYY-MM-DD part of the string
  };
  