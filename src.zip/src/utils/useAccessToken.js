// hooks/useAccessToken.js
import { useMsal } from "@azure/msal-react";
import { useState, useEffect } from "react";

const useAccessToken = () => {
  const { instance, accounts } = useMsal();
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchToken = async () => {
      try {
        const tokenResponse = await instance.acquireTokenSilent({
          scopes: ["User.Read"],
          account: accounts[0],
        });
        setToken(tokenResponse.accessToken);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchToken();
  }, [instance, accounts]);

  return { token, loading, error };
};

export default useAccessToken;
